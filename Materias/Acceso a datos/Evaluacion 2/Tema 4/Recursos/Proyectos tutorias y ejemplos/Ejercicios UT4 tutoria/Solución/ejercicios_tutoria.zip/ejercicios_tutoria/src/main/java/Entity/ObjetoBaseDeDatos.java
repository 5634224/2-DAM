package Entity;

public interface ObjetoBaseDeDatos {

    public int getId();
    public void setId(int id);


}
