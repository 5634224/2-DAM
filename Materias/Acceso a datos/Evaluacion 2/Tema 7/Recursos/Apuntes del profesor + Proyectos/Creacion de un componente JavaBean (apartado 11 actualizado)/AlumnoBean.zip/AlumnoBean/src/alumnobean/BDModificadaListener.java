package alumnobean;

import java.util.EventListener;

public interface BDModificadaListener extends EventListener
{
    public void capturarBDModificada(BDModificadaEvent ev);
}
