package alumnobean;

import java.sql.Date;

public class Alumno 
{

    private String DNI;
    private String Nombre;
    private String Apellidos;
    private String Direccion;
    private Date FechaNac;

    public Alumno(){}

    public Alumno(String DNI, String Nombre, String Apellidos, String Direccion, Date FechaNac)
    {
      this.DNI = DNI;
      this.Nombre = Nombre;
      this.Apellidos = Apellidos;
      this.Direccion = Direccion;
      this.FechaNac = FechaNac;
    }
    
    public String getDNI() {
        return DNI;
    }

    public void setDNI(String DNI) {
        this.DNI = DNI;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public String getApellidos() {
        return Apellidos;
    }

    public void setApellidos(String Apellidos) {
        this.Apellidos = Apellidos;
    }

    public String getDireccion() {
        return Direccion;
    }

    public void setDireccion(String Direccion) {
        this.Direccion = Direccion;
    }

    public Date getFechaNac() {
        return FechaNac;
    }

    public void setFechaNac(Date FechaNac) {
        this.FechaNac = FechaNac;
    }

    @Override
    public String toString() 
    {
        return "Alumno{" + "DNI=" + DNI + ", Nombre=" + Nombre + ", Apellidos=" + Apellidos + ", Direccion=" + Direccion + ", FechaNac=" + FechaNac + '}';
    }
    
    
    
}
