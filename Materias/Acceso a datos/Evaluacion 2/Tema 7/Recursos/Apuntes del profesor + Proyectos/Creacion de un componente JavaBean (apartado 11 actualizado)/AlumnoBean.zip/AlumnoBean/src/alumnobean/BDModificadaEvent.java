package alumnobean;

public class BDModificadaEvent extends java.util.EventObject
{
    //Constructor
    public BDModificadaEvent(Object source)
    {
        super(source);
    }
}    
