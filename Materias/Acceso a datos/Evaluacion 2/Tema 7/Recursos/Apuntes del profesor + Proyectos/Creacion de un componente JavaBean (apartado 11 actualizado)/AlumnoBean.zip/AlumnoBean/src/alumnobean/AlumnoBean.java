package alumnobean;

import java.beans.PropertyChangeSupport;
import java.io.Serializable;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;

public class AlumnoBean implements Serializable
{
    public AlumnoBean() 
    {  
       recargarFilas();
    }
    
    /******************************************************
     * Usaremos un vector auxiliar para cargar la información de la
     * tabla de forma que tengamos acceso a los datos sin necesidad
     * de estar conectados constantemente
     */
    private ArrayList<Alumno> alumnos = new ArrayList();

    /*******************************************************
     * Actualiza el contenido de la tabla en el vector de alumnos
     * Las propiedades contienen el valor del primer elementos de la tabla
     */
    private void recargarFilas() 
    {
        try 
        {
            Connection con = DriverManager.getConnection("jdbc:postgresql://localhost/ad07", 
                    "postgres", "sanpedro");
            
            Statement s = con.createStatement();
            
            ResultSet rs = s.executeQuery ("select * from alumno");
            
            while (rs.next())
            {
                Alumno a = new Alumno(rs.getString("DNI"),
                                      rs.getString("Nombre"),
                                      rs.getString("Apellidos"),
                                      rs.getString("Direccion"),
                                      rs.getDate("FechaNac"));

                alumnos.add(a);
            }   

            rs.close();
            con.close();
            
        } 
        catch (SQLException ex) 
        {
            System.out.println("Error al conectar con la BBDD");
        }
    }
    
    /********************************************************
     *
     * @param i numero de la fila a cargar en las propiedades del componente
     */
    public Alumno seleccionarFila(int i)
    {
        if( i < alumnos.size())
        { 
            return alumnos.get(i);      
        }
        else
        {
            return null;
        }    
     
    }

    /********************************************************
     *
     * @param DNI DNI A buscar, se carga en las propiedades del componente
     */
    public Alumno seleccionarDNI(String DNI)
    {   
        int i=0;
        
        while((i< alumnos.size()) && (!DNI.equals(alumnos.get(i).getDNI())))
        {
            i++;
        }
        
        if (i == alumnos.size())
        {
            return null;
        }   
        else
        {
            return alumnos.get(i);
        }    
    }
    
    /*********************** GESTIÓN DE EVENTOS *****************************************/
    
    /* Objeto que recibirá la notificación de que la BD ha sido actualizada */
    private BDModificadaListener receptor;

    /* Métodos para asignar o eliminar el objeto que recibirá la notificación de que la BD,
    ha sido actualizada */
    public void addBDModificadaListener(BDModificadaListener receptor)
    {
        this.receptor = receptor;
    }
    
    public void removeBDModificadaListener(BDModificadaListener receptor)
    {
        this.receptor=null;
    }
    
    /*******************************************************
     * Método que añade un alumno a la base de datos
     * añade un registro a la base de datos formado a partir
     * de los valores de las propiedades del componente.
     *
     * Se presupone que se han usado los métodos set para configurar
     * adecuadamente las propiedades con los datos del nuevo registro.
     */
    public void addAlumno(Alumno a) 
    {
        try 
        {
            Connection con = DriverManager.getConnection("jdbc:postgresql://localhost/ad07", 
                    "postgres", "sanpedro");
            
            PreparedStatement s = con.prepareStatement("insert into alumno values (?,?,?,?,?)");

            s.setString(1, a.getDNI());
            s.setString(2, a.getNombre());
            s.setString(3, a.getApellidos());
            s.setString(4, a.getDireccion());
            s.setDate(5, a.getFechaNac());

            s.executeUpdate ();
            
            recargarFilas();
            
            receptor.capturarBDModificada( new BDModificadaEvent(this));
        }
        catch(SQLException ex)
        {
            Logger.getLogger(AlumnoBean.class.getName()).log(Level.SEVERE, null, ex);
        }
    }   
}
