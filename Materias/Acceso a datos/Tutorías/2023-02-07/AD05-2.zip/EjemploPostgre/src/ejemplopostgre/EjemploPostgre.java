package ejemplopostgre;

import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author lucasjosemoraleschacon
 */
public class EjemploPostgre {

    
    public static void main(String[] args) 
    {
        
        //1. Realizar conexión
        
        //cadena url de la base de datos anaconda en el servidor local
        String url = "jdbc:postgresql://localhost/ad05";

        //conexión con la base de datos
        Connection conn = null;

        try 
        {
            
          //Abre la conexión con la base de datos a la que apunta el url
          //mediante la contraseña del usuario postgres
          conn = DriverManager.getConnection(url, "postgres", "sanpedro");
          
          /** TIPOS ESTRUCTURADOS **/

          //Elimina la tabla y los tipos de datos (si existen)
          //dropEjemplo(conn);

          //Crea el tipo de dato Dirección
          //crearTipoDireccion(conn);

          //Crea una tabla basada en el nuevo tipo de dato
          //crearTablaIES(conn);

          //introduce algunos registros de ejemplo
          //insertarRegistros(conn);

          //realiza alguna consultas
          //consultaEjemplo1(conn);

          //Modifica algunos registros
          //updateEjemplo(conn);

          //Borra algunos registros
          //deleteEjemplo(conn);
          
          /** ARRAYS **/
          
          //Crea una tabla con un campos array
          gestionTablaAlumnos(conn);

        } 
        catch (SQLException ex) 
        {
          //imprime la excepción
          System.out.println(ex.toString());
          
        } 
        finally 
        {

            try {
                //cierra la conexión
                conn.close();
            } catch (SQLException ex) 
            {
                Logger.getLogger(EjemploPostgre.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
  }
    
  /****************************************************************************
   * Borra todos los objetos antes de volver a crearlos (el orden de borrado
   * es inverso al de su creación)
   *
   * @param conn
   * @throws SQLException
   */
  private static void dropEjemplo(Connection conn) throws SQLException 
  {

    //consulta SQL
    String consulta = "DROP TABLE IF EXISTS ies_rm;"
            + "DROP TYPE IF EXISTS direccion";

    //comando auxiliar para ejecutar la consulta
    Statement sta = conn.createStatement();

    //ejecuta la consulta
    sta.execute(consulta);

    //cierra el objeto auxiliar
    sta.close();
    
  }
  
  //2. Crear un tipo
  
  /****************************************************************************
   * crea el tipo de dato vivienda y el tipo de dato direccion
   * 
   * @param conn
   * @throws SQLException 
   */
  private static void crearTipoDireccion(Connection conn) throws SQLException 
  {

    //consulta SQL
    String consulta = "CREATE TYPE direccion AS("
            + "calle varchar(40), "
            + "ciudad varchar(25))";

    //comando auxiliar para ejecutar la consulta
    Statement sta = conn.createStatement();

    //ejecuta la consulta
    sta.execute(consulta);

    //cierra el objeto auxiliar
    sta.close();
    
  }
        
        
  //3. Crear una tabla con un tipo
  
  /****************************************************************************
   * crea una tabla basada en los nuevos tipos de datos, con una clave principal
   * de tipo serial
   * 
   * @param conn
   * @throws SQLException 
   */
  private static void crearTablaIES(Connection conn) throws SQLException {

    //consulta SQL
    String consulta = "CREATE TABLE ies_rm("
            + "ies_id serial,"
            + "nombre varchar(40),"
            + "ubicacion direccion, "
            + "CONSTRAINT ies_rm_id PRIMARY KEY (ies_id)"
            + ")";

    //comando auxiliar para ejecutar la consulta
    Statement sta = conn.createStatement();

    //ejecuta la consulta
    sta.execute(consulta);

    //cierra el objeto auxiliar
    sta.close();
    
  }
  
  //4. Insert en una tabla con un tipo estructurado
  /****************************************************************************
   * inserta unos cuantos registros de ejemplo
   * 
   * @param conn
   * @throws SQLException 
   */
  private static void insertarRegistros(Connection conn) throws SQLException {

    //consulta SQL
    String consulta = "INSERT INTO ies_rm("
            + "nombre,ubicacion) VALUES("
            + "'CIFP Carlos III',"
            + "ROW('C/Carlos III, 3','Cartagena'));" 
            
            + "INSERT INTO ies_rm("
            + "nombre,ubicacion) VALUES("
            + "'IES EUROPA',"
            + "ROW('Calle de Miguel Ángel Blanco, 11','Águilas'));" 
            
            + "INSERT INTO ies_rm("
            + "nombre,ubicacion) VALUES("
            + "'IES JIMÉNEZ DE LA ESPADA',"
            + "ROW('Paseo Alfonso XIII, 4','Cartagena'));";

    //comando auxiliar para ejecutar la consulta
    Statement sta = conn.createStatement();

    //ejecuta la consulta
    sta.execute(consulta);

    //cierra el objeto auxiliar
    sta.close();
  }
        
  //5. Consulta de un tipo
  
  /****************************************************************************
   * muestra todas los IES de la RM
   * 
   * @param conn
   * @throws SQLException 
   */
  private static void consultaEjemplo1(Connection conn) throws SQLException 
  {

    //
    System.out.print("\nTodos los IES de la Región de Murcia:\n");

    //consulta SQL
    String consulta = "SELECT * FROM ies_rm WHERE (ies_rm.ubicacion).ciudad='Cartagena'";

    //comando auxiliar para ejecutar la consulta
    Statement sta = conn.createStatement();

    //ejecuta la consulta para que devuelva un conjunto de registros
    ResultSet res = sta.executeQuery(consulta);

    //imprime el resultado
    imprimirResultSet(res);

    //cierra los objetos auxiliares
    res.close();
    sta.close();
  }

  /****************************************************************************
   * imprime en la Salida el resultSet especificado, con los datos de cada
   * columna tabulados
   * 
   * @param resultSet
   * @throws SQLException 
   */
  private static void imprimirResultSet(ResultSet resultSet) throws SQLException 
  {

    //Número de columnas del resultset
    ResultSetMetaData metaDatos = resultSet.getMetaData();
    int columnas = metaDatos.getColumnCount();

    //Mientras quedan registros por leer en el ResultSet
    
    while (resultSet.next()) 
    {
      //imprime los registros
      for (int i = 1; i <= columnas; i++) 
      {
        //seguidos de un espacio
        System.out.print(resultSet.getString(i) + " ");
      }

      //hueco entre registros
      System.out.println();
    }
    
  }
  
  //6. Modificación de una tabla con un tipo
  
  /****************************************************************************
   * Cambiamos la dirección de un IES
   * 
   * @param conn
   * @throws SQLException 
   */
  private static void updateEjemplo(Connection conn) throws SQLException 
  {

    //consulta SQL
    String consulta = "UPDATE ies_rm "
            + "SET ubicacion.calle='Alameda de San Antón, 52' "
            + "WHERE "
            + "nombre='CIFP Carlos III'";

    //Comando SQL
    Statement sta = conn.createStatement();

    //Ejecuta la consulta para que muestre las filas afectadas
    System.out.print("\nComo resultado, " + sta.executeUpdate(consulta)
            + " fila actualizada:\n");

    //Nueva consulta SQL
    consulta = "SELECT * "
            + "FROM ies_rm "
            + "WHERE nombre='CIFP Carlos III'";

    //Reutiliza el comando para enviar la nueva consulta y que
    //devuelva un ResultSet
    ResultSet res = sta.executeQuery(consulta);

    //imprime el resultado
    imprimirResultSet(res);

    //cierra los objetos auxiliares
    res.close();
    sta.close();
    
  }
  
  
  //7. Eliminación en una tabla con un tipo
  /****************************************************************************
   * Borra los IES de Cartagena
   * 
   * @param conn
   * @throws SQLException 
   */
  private static void deleteEjemplo(Connection conn) throws SQLException 
  {

    //
    System.out.print("\nBorramos los IES de Cartagena");

    //consulta SQL
    String consulta = "DELETE "
            + "FROM ies_rm "
            + "WHERE (ies_rm.ubicacion).ciudad='Cartagena'";

    //comando SQL
    Statement sta = conn.createStatement();

    //ejecuta la consulta para que muestre el número de filas eliminadas
    System.out.print("\nComo resultado, " + sta.executeUpdate(consulta)
            + " fila/s eliminada/s\n\n");

    //nueva consulta SQL
    consulta = "SELECT * "
            + "FROM ies_rm";

    //reutiliza el comando para enviar la nueva consulta y que
    //devuelva un ResultSet
    ResultSet res = sta.executeQuery(consulta);
    
    System.out.println("Los institutos que quedan son: ");

    //imprime el resultado
    imprimirResultSet(res);

    //cierra los objetos auxiliares
    res.close();
    sta.close();
    
  }

  //8. Crear una tabla con un array. Consulta y actualización de un array
  /****************************************************************************
   * Gestión de alumnos
   * 
   * @param conn
   * @throws SQLException 
   */
  private static void gestionTablaAlumnos(Connection conn) throws SQLException 
  {
      
        /** DROP **/
      
        //DROP SQL
        String consulta =   "DROP TABLE IF EXISTS alumnos";
        
        //comando auxiliar para ejecutar la consulta
        Statement sta = conn.createStatement();

        //ejecuta la consulta
        sta.execute(consulta);

        //cierra el objeto auxiliar
        sta.close();
        

        /** CREATE **/
        
        //Create SQL
        consulta =          "CREATE TABLE alumnos("
                            + "alumno_id serial,"
                            + "nombre varchar(40),"
                            + "asignaturas varchar[])";
    
        //comando auxiliar para ejecutar la consulta
        sta = conn.createStatement();

        //ejecuta la consulta
        sta.execute(consulta);

        //cierra el objeto auxiliar
        sta.close();
    
    
        /** INSERT **/
        
        //INSERT SQL
        consulta =      "INSERT INTO alumnos("
                        + "nombre,asignaturas) VALUES("
                        + "'Lucas',"
                        + "ARRAY ['POO', 'BBDD', 'PSP']);" 

                        + "INSERT INTO alumnos("
                        + "nombre,asignaturas) VALUES("
                        + "'Jaime',"
                        + "ARRAY ['PMyDM', 'DI', 'AD'])";
    
        //comando auxiliar para ejecutar la consulta
        sta = conn.createStatement();

        //ejecuta la consulta
        sta.execute(consulta);

        //cierra el objeto auxiliar
        sta.close();
        
        /** SELECT **/
        
        System.out.println("Todos los alumnos con todas sus asignaturas:");
        //SELECT SQL
        consulta =      "SELECT * FROM alumnos";
    
        //comando auxiliar para ejecutar la consulta
        sta = conn.createStatement();

        //Reutiliza el comando para enviar la nueva consulta y que
        //devuelva un ResultSet
        ResultSet res = sta.executeQuery(consulta);

        //imprime el resultado
        imprimirResultSet(res);

        //cierra los objetos auxiliares
        res.close();
        sta.close();

        System.out.println("");
        
        
        System.out.println("Alumnos y su primera asignatura:");
        
        //SELECT SQL - Opción 2 - Primera asignatura solo
        consulta =      "SELECT alumno_id, nombre, asignaturas[1] FROM alumnos;";
    
        //comando auxiliar para ejecutar la consulta
        sta = conn.createStatement();

        //Reutiliza el comando para enviar la nueva consulta y que
        //devuelva un ResultSet
        res = sta.executeQuery(consulta);

        //imprime el resultado
        imprimirResultSet(res);

        //cierra los objetos auxiliares
        res.close();
        sta.close();
        
        /** UPDATE **/
        
        System.out.println("");
        System.out.println("Le cambiamos al alumno 1 POO por ED:");
        //SELECT SQL
        consulta =      "UPDATE alumnos SET asignaturas[1] = 'ED' WHERE alumno_id = 1;";
    
        //comando auxiliar para ejecutar la consulta
        sta = conn.createStatement();
        
        System.out.println("Se han modificado " + sta.executeUpdate(consulta) + " líneas");

        //Reutiliza el comando para enviar la nueva consulta y que
        //devuelva un ResultSet
        System.out.println("");
        consulta = "SELECT * FROM alumnos ORDER  BY alumno_id ASC";
        res = sta.executeQuery(consulta);

        System.out.println("Todos los alumnos después del Update");
        //imprime el resultado
        imprimirResultSet(res);

        //cierra los objetos auxiliares
        res.close();
        sta.close();
        
        /** DELETE **/
        
        System.out.println("");
        System.out.println("Eliminamos al alumno con id=2:");
        //SELECT SQL
        consulta =      "DELETE FROM alumnos WHERE alumno_id = 2;";
    
        //comando auxiliar para ejecutar la consulta
        sta = conn.createStatement();
        
        System.out.println("Se han modificado " + sta.executeUpdate(consulta) + " líneas");

        //Reutiliza el comando para enviar la nueva consulta y que
        //devuelva un ResultSet
        System.out.println("");
        consulta = "SELECT * FROM alumnos ORDER  BY alumno_id ASC";
        res = sta.executeQuery(consulta);

        System.out.println("Todos los alumnos después del Delete");
        //imprime el resultado
        imprimirResultSet(res);

        //cierra los objetos auxiliares
        res.close();
        sta.close();
      
  }
        
}
    

