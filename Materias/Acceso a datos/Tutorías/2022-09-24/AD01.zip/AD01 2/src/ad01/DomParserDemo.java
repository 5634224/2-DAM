package ad01;

import static ad01.AD01.BASE;
import java.io.File;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.w3c.dom.Element;

public class DomParserDemo 
{
    static final String SEPARADOR = System.getProperty("file.separator");// '/'
    static final String BASE = System.getProperty("user.dir") + SEPARADOR + "AD01" + SEPARADOR;
    
    public static void main(String[] args) 
    {
        try 
        {
             File inputFile = new File(BASE+"clase.xml");
             File outputFile = new File(BASE+"salida.xml");
             
             DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
             DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
             Document doc = dBuilder.parse(inputFile);
             
             doc.getDocumentElement().normalize();
             
             /** Mostrar toda la información contenida en el fichero XML **/
             
             System.out.println("Root element :" + 
                doc.getDocumentElement().getNodeName());
             
             NodeList nList = doc.getElementsByTagName("alumno");
             System.out.print("----------------------------");

             for (int temp = 0; temp < nList.getLength(); temp++) 
             {
                Node nNode = nList.item(temp);
                System.out.println("\nCurrent Element :" + nNode.getNodeName());

                if (nNode.getNodeType() == Node.ELEMENT_NODE) 
                {
                    Element eElement = (Element) nNode;
                    System.out.println("numero de alumno : "+ eElement.getAttribute("numero"));
                    System.out.println("nombre : "+ eElement.getElementsByTagName("nombre").item(0).getTextContent());
                    System.out.println("apellido :"+ eElement.getElementsByTagName("apellido").item(0).getTextContent());
                    System.out.println("apodo : "+ eElement.getElementsByTagName("apodo").item(0).getTextContent());
                    System.out.println("marcas : "+eElement.getElementsByTagName("marcas").item(0).getTextContent());
                 }

                
                
             }
             
             /** Añadir un nuevo ALUMNO al DOM**/
             
            //Obtenemos el elemento raíz 
            Element raiz = doc.getDocumentElement();
             
            //Elemento Alumno
            Element nuevoAlumno = doc.createElement("alumno");
            raiz.appendChild(nuevoAlumno);
            
            //Atributo número
            Attr numero = doc.createAttribute("numero");
            numero.setValue("693");
            nuevoAlumno.setAttributeNode(numero);
            
            //Nombre
            Element nombre = doc.createElement("nombre");
            nombre.setTextContent("Manolito");
            nuevoAlumno.appendChild(nombre);
            
            //Apellido
            Element apellido = doc.createElement("apellido");
            apellido.setTextContent("Morales");
            nuevoAlumno.appendChild(apellido);
            
            //Apodo
            Element apodo = doc.createElement("apodo");
            apodo.setTextContent("gafotas");
            nuevoAlumno.appendChild(apodo);
            
            //Marcas
            Element marcas = doc.createElement("marcas");
            marcas.setTextContent("100");
            nuevoAlumno.appendChild(marcas);
            
            System.out.println("");

            
            /** Mostrar toda la información contenida en el DOM **/
             
             System.out.println("Root element :" + 
                doc.getDocumentElement().getNodeName());
             
             nList = doc.getElementsByTagName("alumno");
             System.out.print("----------------------------");

             for (int temp = 0; temp < nList.getLength(); temp++) 
             {
                Node nNode = nList.item(temp);
                System.out.println("\nCurrent Element :" + nNode.getNodeName());

                if (nNode.getNodeType() == Node.ELEMENT_NODE) 
                {
                    Element eElement = (Element) nNode;
                    System.out.println("numero de alumno : "+ eElement.getAttribute("numero"));
                    System.out.println("nombre : "+ eElement.getElementsByTagName("nombre").item(0).getTextContent());
                    System.out.println("apellido :"+ eElement.getElementsByTagName("apellido").item(0).getTextContent());
                    System.out.println("apodo : "+ eElement.getElementsByTagName("apodo").item(0).getTextContent());
                    System.out.println("marcas : "+eElement.getElementsByTagName("marcas").item(0).getTextContent());
                 }

             }
            
            //Se escribe el contenido del DOM en un archivo
            TransformerFactory transformerFactory = TransformerFactory.newInstance();
            Transformer transformer = transformerFactory.newTransformer();
            DOMSource source = new DOMSource(doc);
            
            StreamResult result = new StreamResult(outputFile);
            
            transformer.transform(source, result); 
            
            
        }
        catch (Exception e) 
        {
              e.printStackTrace();
        }
    
    }//main
}//class 
