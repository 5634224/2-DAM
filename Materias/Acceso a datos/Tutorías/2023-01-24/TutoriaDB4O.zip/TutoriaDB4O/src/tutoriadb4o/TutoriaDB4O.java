package tutoriadb4o;

import com.db4o.Db4oEmbedded;
import com.db4o.ObjectContainer;
import com.db4o.ObjectSet;
import com.db4o.query.Predicate;
import com.db4o.query.Query;
import java.io.File;

public class TutoriaDB4O 
{
    public static void main(String[] args) 
    {
        File f = new File("personas.db4o");
        f.delete(); // Lo borramos para que no se repitan los objetos
        
        //Creamos la conexión. Si el fichero no existe, lo crea.
        ObjectContainer db = Db4oEmbedded.openFile("personas.db4o"); 
        
        // Creamos los objetos
        Persona p1 = new Persona("Fernando", 30, 73, 1.73, null);
        Persona p2 = new Persona("Pepe", 30, 75, 1.80, null);
        Persona p3 = new Persona("Alfredo", 20, 90, 1.90, null);
        Persona p4 = new Persona("Roberto", 35, 70, 1.70, null);
        Persona p5 = new Persona("Domingo", 30, 73, 1.80, null);

        //Indicamos que Pepe es el padre de Fernando
        p1.setPadre(p2);
        p3.setPadre(p4);
        
        //Guardamos los objetos en la base de datos
        db.store(p1);
        db.store(p2);
        db.store(p3);
        db.store(p4);
        db.store(p5);
            
        /** Opción 1: CONSULTAS POR EJEMPLO - QuerybyExample 
        
        Persona p = new Persona();
        p.setAltura(1.70);
        
        ObjectSet<Persona> result = db.queryByExample(p);

        System.out.println("Todos los objetos");
        
        while (result.hasNext()) 
        {
            System.out.println(result.next());
        }
        
        System.out.println("");

        db.close(); **/
        
        
        /** Opción 2: Consultas SODA = Simple Object Data Access 
        //Creamos la consulta
        Query query = db.query();

        //Si ponemos la clase del objeto, nos aparecerán todos los objetos de ese tipo.
        query.constrain(Persona.class);
        //Con descend indicamos el atributo sobre el que aplicar la restricción
        query.descend("altura").constrain(1.70);

        ObjectSet<Persona> result = query.execute();

        System.out.println("Todos los objetos");
        while (result.hasNext()) 
        {
            System.out.println(result.next());
        }
        System.out.println("");

        db.close();**/
        
        /** CONSULTAS NATIVAS - Permiten consultas sobre objetos No SODA 
            
        ObjectSet result = db.query(

            new Predicate<Persona>()
            {
                @Override    
                public boolean match(Persona p) 
                {
                    return (p.getPadre().getAltura() == 1.70) ;
                }
            });

        System.out.println("Native Query");
        while (result.hasNext()) 
        {
            System.out.println(result.next());
        }
        System.out.println("");

        db.close(); **/
        
        /** ACTUALIZACIÓN Y ELIMINACIÓN DE OBJETOS **/
            
        Persona p = new Persona();

        ObjectSet<Persona> result = db.queryByExample(p);

        System.out.println("Todos");
        while (result.hasNext()) 
        {
            System.out.println(result.next());
        }
        System.out.println("");

        //Obtenemos solo al que se llama Fernando    
        p.setNombre("Fernando");
        result = db.queryByExample(p);

        Persona pAux = result.next();
        pAux.setPadre(null);

        //Todos
        p = new Persona();
        result = db.queryByExample(p);

        System.out.println("Todos - Fernando sin padre");
        while (result.hasNext()) 
        {
            System.out.println(result.next());
        }
        System.out.println("");

        //Eliminamos a Fernando
        db.delete(pAux);

        p = new Persona();
        result = db.queryByExample(p);

        System.out.println("Todos - Fernando eliminado");
        while (result.hasNext()) 
        {
            System.out.println(result.next());
        }
        System.out.println("");


        db.close();
        
    }
    
}
