
package jdbc_aplicacion.clases;

//Crear la clase empleado
public class Empleado {
    
}
