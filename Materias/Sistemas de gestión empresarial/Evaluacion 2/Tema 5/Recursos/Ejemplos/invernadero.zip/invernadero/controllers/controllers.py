# -*- coding: utf-8 -*-
# from odoo import http


# class Invernadero(http.Controller):
#     @http.route('/invernadero/invernadero', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/invernadero/invernadero/objects', auth='public')
#     def list(self, **kw):
#         return http.request.render('invernadero.listing', {
#             'root': '/invernadero/invernadero',
#             'objects': http.request.env['invernadero.invernadero'].search([]),
#         })

#     @http.route('/invernadero/invernadero/objects/<model("invernadero.invernadero"):obj>', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('invernadero.object', {
#             'object': obj
#         })
