# -*- coding: utf-8 -*-

from odoo import models, fields, api


class invernadero(models.Model):
     _name = 'invernadero.invernadero'
     _description = 'Lista de plantas'

     planta = fields.Char()
     cantidad = fields.Integer()
     tipo = fields.Selection(
         string ='Tipo de planta',
         selection=[
             ('frutal','Frutal'),
             ('catus','Cactus'),
             ('interior','Planta de interior'),
             ('exterior','Planta de exterior')
         ]
     )
#     description = fields.Text()
#
#     @api.depends('value')
#     def _value_pc(self):
#         for record in self:
#             record.value2 = float(record.value) / 100
