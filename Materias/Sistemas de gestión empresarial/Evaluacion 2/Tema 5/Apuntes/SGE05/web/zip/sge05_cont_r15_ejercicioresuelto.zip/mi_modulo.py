import funciones
funciones.bienvenida()
