package com.psp.repaso;

import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class InetAddress_URL_HTTP {
    public static void obtenerInformacionURL(String URL) {
        try {
            URL url = new URL("https://cifpcarlos3.es/es");
            System.out.println("protocol = " + url.getProtocol());
            System.out.println("host = " + url.getHost());
            System.out.println("filename = " + url.getFile());
            System.out.println("port = " + url.getDefaultPort());
            System.out.println("ref = " + url.getRef());
        } catch (MalformedURLException e) {
            throw new RuntimeException(e);
        }
    }

    public static void descargarFicheroURL(String URL, String rutaDestino) {
        try {
            // Creamos la URL
            URL url = new URL(URL);

            System.out.println("protocol = " + url.getProtocol());
            System.out.println("host = " + url.getHost());
            System.out.println("filename = " + url.getFile());
            System.out.println("port = " + url.getDefaultPort());
            System.out.println("ref = " + url.getRef());//En este caso no tiene "anchor"

            // Conecta a esa URL
            InputStream flujoIn = url.openStream();
            BufferedInputStream in = new BufferedInputStream(flujoIn);

            //url.getFile obtiene toda la ruta, sólo queremos el nombre del fichero
            String[] rutas = url.getFile().split("/");
            String nombreArchivo = rutas[rutas.length - 1];
            System.out.println("Nombre del fichero a descargar " + nombreArchivo);

            // Creamos el flujo para guardar el fichero
            FileOutputStream fileOutput = new FileOutputStream(rutaDestino + "/" + nombreArchivo);
            BufferedOutputStream bufferedOutput = new BufferedOutputStream(fileOutput);

            // Bucle para leer de un fichero y escribir en el otro.
            byte[] array = new byte[1000];
            int leidos = in.read(array);
            while (leidos > 0) {
                bufferedOutput.write(array, 0, leidos);
                leidos = in.read(array);
            }

            // Cerramos
            in.close();
            bufferedOutput.close();
            fileOutput.close();
        } catch (MalformedURLException ex) {
            System.err.println("Error URL mal formada " + ex);
        } catch (IOException ex) {
            System.err.println("Error " + ex);
        }
    }

    public static InetAddress getInetAddress(String URL) {
        // Obtiene el objeto InteAddress de la direccion especificada
        try {
            InetAddress inet = InetAddress.getByName(URL);
            System.out.println("Nombre del equipo de " + URL + ":" + inet.getHostName());
            System.out.println("IP de " + URL + ":" + inet.getHostAddress());

            return inet;
        } catch (UnknownHostException e) {
            throw new RuntimeException(e);
        }
    }

    public static InetAddress[] getAllInetAddress(String URL) {
        try {
            // Encapsula la URL
            InetAddress[] matrizAddress = InetAddress.getAllByName(URL);

            // Obtiene y muestra todas las IP asociadas a ese host
            System.out.println("Imprime todas las IP disponibles para " + URL + ": ");
            for (int i = 0; i < matrizAddress.length; i++) {
                System.out.println(matrizAddress[i].getHostAddress());
            }

            return matrizAddress;
        } catch (UnknownHostException e) {
            throw new RuntimeException(e);
        }
    }

    public static void sendRequest(String URL, HashMap<String, String> parametros, String method) {
        // Constantes
        final String USER_AGENT = "Mozilla/5.0";

        // Envia una petición a la URL especificada
        try {
            // Prepara la URL y configura las cabeceras de la petición
            if (method.equals("GET")) {
                // Prepara los parámetros con el método correspondiente (GET)
                URL = prepareGetParameters(URL, parametros);
            }

            URL obj = new URL(URL);
            HttpURLConnection con = (HttpURLConnection) obj.openConnection();

            con.setRequestMethod(method);
            con.setRequestProperty("User-Agent", USER_AGENT);

            // Si el método es POST, prepara los parámetros con el método correspondiente (POST)
            if (method.equals("POST")) {
                preparePostParameters(con, parametros);
            }

            // Envía la petición y recibe la respuesta
            int responseCode = con.getResponseCode();
            System.out.println(method + " Response Code : " + responseCode);
            System.out.println(method + " Response Message : " + con.getResponseMessage());

            // Imprime las cabeceras de la respuesta
            for (Map.Entry<String, List<String>> header : con.getHeaderFields().entrySet()) {
                System.out.println(header.getKey() + "=" + header.getValue());
            }

            // Imprime la respuesta
            if (responseCode == HttpURLConnection.HTTP_OK) {
                // Abre un flujo de lectura y lee la respuesta
                BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
                String inputLine;
                StringBuffer response = new StringBuffer();

                while ((inputLine = in.readLine()) != null) {
                    response.append(inputLine);
                }
                in.close();

                System.out.println(response.toString());
            } else {
                System.out.println(method + " request not worked");
            }
        } catch (MalformedURLException ex) {
            System.err.println("Error URL mal formada " + ex);
        } catch (IOException ex) {
            System.err.println("Error " + ex);
        }
    }

    public static String prepareGetParameters(String URL, HashMap<String, String> parametros) {
        // Prepara los parámetros para una petición GET
        StringBuilder urlBuild = new StringBuilder(URL + "?");
        for (Map.Entry<String, String> entry : parametros.entrySet()) {
            urlBuild.append(entry.getKey() + "=" + entry.getValue() + "&");
        }

        if (!urlBuild.isEmpty()) {
            urlBuild.deleteCharAt(urlBuild.length() - 1);
        }

        // Devuelve la URL con los parámetros
        return urlBuild.toString();
    }

    public static void preparePostParameters(HttpURLConnection con, HashMap<String, String> parametros) throws IOException {
        // Prepara los parámetros para una petición POST
        StringBuilder parameters = new StringBuilder();
        for (Map.Entry<String, String> entry : parametros.entrySet()) {
            parameters.append(URLEncoder.encode(entry.getKey(), StandardCharsets.UTF_8));
            parameters.append("=");
            parameters.append(URLEncoder.encode(entry.getValue(), StandardCharsets.UTF_8));
            parameters.append("&");
        }

        // Elimina el último carácter
        if (!parameters.isEmpty()) {
            parameters.deleteCharAt(parameters.length() - 1);
        }

        // Envía los parámetros
        con.setDoOutput(true); // Habilita el envío de parámetros y configura la conexión para utilizar POST
        DataOutputStream wr = new DataOutputStream(con.getOutputStream());
        wr.writeBytes(parameters.toString());
        wr.flush();
        wr.close();
    }

    public static void getRequestURL(String URL, HashMap<String, String> parametros) {
        sendRequest(URL, parametros, "GET");
    }

    public static void postRequestURL(String URL, HashMap<String, String> parametros) {
        sendRequest(URL, parametros, "POST");
    }
}
