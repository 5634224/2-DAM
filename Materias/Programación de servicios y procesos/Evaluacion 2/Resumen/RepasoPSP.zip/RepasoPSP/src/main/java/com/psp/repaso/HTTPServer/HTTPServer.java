package com.psp.repaso.HTTPServer;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;

public class HTTPServer {
    private ServerSocket serverSocket;
    private RequestHandler requestHandler;

    public HTTPServer(int port, RequestHandler requestHandler) throws IOException {
        this.serverSocket = new ServerSocket(port);
        this.requestHandler = requestHandler;
    }

    public void start() throws IOException {
        while (true) {
            Socket clientSocket = serverSocket.accept();
            handleClient(clientSocket);
            clientSocket.close();
        }
    }

    private void handleClient(Socket clientSocket) throws IOException {
        BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
        PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true);

        String requestLine = in.readLine();
        Request request = parseRequest(requestLine);
        Response response = requestHandler.handle(request);

        out.println(response.getStatus());
        out.println(response.getHeaders());
        out.println("\n");
        out.println(response.getBody());
    }

    private Request parseRequest(String requestLine) {
        String[] parts = requestLine.split(" ");
        String method = parts[0];
        String path = parts[1];
        return new Request(method, path);
    }
}