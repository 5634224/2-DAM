package com.psp.repaso;

import java.security.MessageDigest;
import java.util.Base64;
import java.security.NoSuchAlgorithmException;

public class Hash {
    /*================ CAMPOS DE CLASE ================*/
    public enum Algoritmo {
        MD5("MD5"), SHA1("SHA1"), SHA256("SHA256"), SHA512("SHA512");

        private String value;

        Algoritmo(String value) {
            this.value = value;
        }

        public String getValue() {
            return value;
        }

        public static Algoritmo fromString(String s) {
            for (Algoritmo algoritmo : Algoritmo.values()) {
                if (algoritmo.getValue().equals(s)) {
                    return algoritmo;
                }
            }
            return null;
        }
    }

    // Método que hashea una cadena de texto
    private static String Codificar(String cadena, Algoritmo algoritmo) {
        try {
            // Selecciona el algoritmo de hash, en este caso SHA-256
            MessageDigest digest = MessageDigest.getInstance(algoritmo.value);

            // Calcula el hash
            byte[] hashBytes = digest.digest(cadena.getBytes());

            // Convierte el hash a Base64
            return Base64.getEncoder().encodeToString(hashBytes);
        } catch (NoSuchAlgorithmException e) {
            System.out.println("ERROR EN LA CODIFICACIÓN: " + e.getMessage());
        }
        return null;
    }
}
