package com.psp.repaso;

import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import static com.psp.repaso.Styles.*;

import static org.apache.logging.log4j.Level.*;

public class Log4J2 {

    /*================ CAMPOS DE CLASE ================*/
    public static final Logger logger = LogManager.getLogger(Log4J2.class);

    /*================ MÉTODOS ================*/
    /**
     * Registra un log tanto en la salida estándar del sistema como en el archivo de log.
     */
    public static void log(Level nivel, String message) {
        if (nivel.equals(TRACE)) {
            System.out.println(ANSI_RESET + "TRACE: " + message);
            logger.log(TRACE, message);
        } else if (nivel.equals(DEBUG)) {
            System.out.println(ANSI_RESET + "DEBUG: " + message);
            logger.log(DEBUG, message);
        } else if (nivel.equals(INFO)) {
            System.out.println(ANSI_RESET + "INFO: " + message);
            logger.log(INFO, message);
        } else if (nivel.equals(WARN)) {
            System.out.println(ANSI_YELLOW + "WARN: " + message);
            logger.log(WARN, message);
        } else if (nivel.equals(ERROR)) {
            System.out.println(ANSI_RED + "ERROR: " + message);
            logger.log(ERROR, message);
        } else if (nivel.equals(FATAL)) {
            System.out.println(ANSI_RED + "FATAL: " + message);
            logger.log(FATAL, message);
        }
    }


}