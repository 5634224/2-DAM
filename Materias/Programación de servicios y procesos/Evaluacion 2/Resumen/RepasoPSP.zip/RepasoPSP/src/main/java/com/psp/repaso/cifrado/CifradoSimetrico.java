package com.psp.repaso.cifrado;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.KeyGenerator;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;

public class CifradoSimetrico {
    public CifradoSimetrico() {
        // Declara e incializa objeto tipo clave secreta
        SecretKey clave = null;

        // Llama a los métodos que encripta/desencripta un fichero
        try {
            // Llama al método que encripta el fichero que se pasa como parámetro
            clave = cifrarFichero("fichero.txt","fichero.cifrado" );

            // Llama la método que desencripta el fichero pasado como primer parámetro
            descifrarFichero("fichero.cifrado", clave, "fichero.descifrado");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Método que encripta el fichero que se pasa como parámetro
    // devuelve el valor de la clave privada utilizada en encriptación
    // El fichero encriptado lo deja en el archivo de nombre fichero.cifrado
    // en el mismo directorio
    private static SecretKey cifrarFichero(String file, String fileCifrado) throws
            NoSuchAlgorithmException, NoSuchPaddingException, FileNotFoundException, IOException,
            IllegalBlockSizeException, BadPaddingException, InvalidKeyException {
        FileInputStream fe = null; //fichero de entrada
        FileOutputStream fs = null; //fichero de salida

        int bytesLeidos;

        // 1. Crear e inicializar clave
        System.out.println("1.- Genera clave DES");

        // Crea un objeto para generar la clave usando algoritmo DES
        KeyGenerator keyGen = KeyGenerator.getInstance("DES");
        keyGen.init(56); // Se indica el tamaño de la clave
        SecretKey clave = keyGen.generateKey(); // Genera la clave privada
        System.out.println("Clave");
        mostrarBytes(clave.getEncoded()); // Muestra la clave
        System.out.println();

        // Se Crea el objeto Cipher para cifrar, utilizando el algoritmo DES
        Cipher cifrador = Cipher.getInstance("DES");

        // Se inicializa el cifrador en modo CIFRADO o ENCRIPTACIÓN
        cifrador.init(Cipher.ENCRYPT_MODE, clave);
        System.out.println("2.- Cifra con DES el fichero: " + file + ", y deja el resultado en " + fileCifrado);

        // Declaración de objetos
        byte[] buffer = new byte[1000]; // Array de bytes
        byte[] bufferCifrado;
        fe = new FileInputStream(file); // Objeto fichero de entrada
        fs = new FileOutputStream(fileCifrado); // Fichero de salida

        // Lee el fichero de 1k en 1k y pasa los fragmentos leidos al cifrador
        bytesLeidos = fe.read(buffer, 0, 1000);

        // Mientras no se llegue al final del fichero
        while (bytesLeidos != -1) {
            // Pasa texto claro al cifrador y lo cifra, asignándolo a bufferCifrado
            bufferCifrado = cifrador.update(buffer, 0, bytesLeidos);

            fs.write(bufferCifrado); // Graba el texto cifrado en fichero

            bytesLeidos = fe.read(buffer, 0, 1000);
        }

        bufferCifrado = cifrador.doFinal(); // Completa el cifrado

        fs.write(bufferCifrado); //Graba el final del texto cifrado, si lo hay

        //Cierra ficheros
        fe.close();
        fs.close();

        return clave;
    }

    // Método que desencripta el fichero pasado como primer parámetro file1
    // pasándole también la clave privada que necesita para desencriptar, key
    // y deja el fichero desencriptado en el tercer parámetro file2
    private static void descifrarFichero(String file1, SecretKey key, String file2) throws NoSuchAlgorithmException, NoSuchPaddingException,
            FileNotFoundException, IOException, IllegalBlockSizeException, BadPaddingException,
            InvalidKeyException {
        FileInputStream fe = null; //fichero de entrada
        FileOutputStream fs = null; //fichero de salida
        int bytesLeidos;

        Cipher cifrador = Cipher.getInstance("DES");

        // 3.- Pone el cifrador en modo DESCIFRADO o DESENCRIPTACIÓN
        cifrador.init(Cipher.DECRYPT_MODE, key);
        System.out.println("3.- Descifra con DES el fichero: " + file1 + ", y lo deja en " + file2);

        fe = new FileInputStream(file1);
        fs = new FileOutputStream(file2);
        byte[] bufferClaro;
        byte[] buffer = new byte[1000]; // Array de bytes

        // Lee el fichero de 1k en 1k y pasa los fragmentos leidos al cifrador
        bytesLeidos = fe.read(buffer, 0, 1000);

        // Mientras no se llegue al final del fichero
        while (bytesLeidos != -1) {
            // Pasa texto cifrado al cifrador y lo descifra, asignándolo a bufferClaro
            bufferClaro = cifrador.update(buffer, 0, bytesLeidos);

            fs.write(bufferClaro); //Graba el texto claro en fichero

            bytesLeidos = fe.read(buffer, 0, 1000);
        }
        bufferClaro = cifrador.doFinal(); // Completa el descifrado

        fs.write(bufferClaro); // Graba el final del texto claro, si lo hay

        // Cierra archivos
        fe.close();
        fs.close();
    }

    // Método que muestra bytes
    public static void mostrarBytes(byte[] buffer) {
        System.out.write(buffer, 0, buffer.length);
    }
}
