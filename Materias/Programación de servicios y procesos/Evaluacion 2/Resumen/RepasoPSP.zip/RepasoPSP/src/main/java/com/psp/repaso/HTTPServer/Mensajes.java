package com.psp.repaso.HTTPServer;

//Mensajes que intercambia el Servidor con el Cliente según protocolo HTTP
public class Mensajes {
    public static final String lineaInicial_OK = "HTTP/1.1 200 OK";
    public static final String lineaInicial_NotFound = "HTTP/1.1 404 Not Found";


}