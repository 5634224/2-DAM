package com.psp.repaso;

public class ExpresionesRegulares {
    public static boolean verificarExpresionRegular(String expresion, String texto) {
        return texto.matches(expresion);
    }

    public ExpresionesRegulares() {
    }

    public static boolean verificarPrueba(String texto) {
        // Expresión regular de prueba
        String expresionPrueba = "^[ABC]-[19]{5}$";
        
        return texto.matches(expresionPrueba);
    }
}
