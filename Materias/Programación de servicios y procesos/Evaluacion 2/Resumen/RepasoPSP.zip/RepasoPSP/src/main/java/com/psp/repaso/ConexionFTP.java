package com.psp.repaso;

import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPReply;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.SocketException;
import java.util.Properties;
import java.util.Scanner;


public class ConexionFTP {
    // Creacion del objeto para la lectura de la entrada estandar
    private static Scanner scanner = new Scanner(System.in);

    // Objeto de la clase FTPClient de Apache, con diversos métodos para interactuar y recuperar un archivo de un servidor FTP
    private static FTPClient clienteFTP = new FTPClient();

    // URL del servidor local de la máquina, puede ser una URL externa como ftp.rediris.es
    private static String servidorURL_local = "localhost";
    private static String usuario; //usuario
    private static String password; //contraseña


    public ConexionFTP() {
        boolean finPrograma = false;

        LeerProperties();

        try {
            // Conexión del cliente al servidor FTP
            System.out.println("\n>>> CONECTANDO CON EL SERVIDOR FTP....\n");
            clienteFTP.connect(servidorURL_local);
            MostrarRespuestasFTP(); // Muestra los mensajes de respuesta

            // Comienza si la conexión es satisfactoria
            if (FTPReply.isPositiveCompletion(clienteFTP.getReplyCode())) {
                System.out.println("\n>>> CONEXIÓN ESTABLECIDA\n");

                // Abre una sesión con el usuario anónimo
                clienteFTP.login(usuario, password);
                MostrarRespuestasFTP();

                //Activar el modo pasivo para no tener problemas con el Firewall de Windows
                clienteFTP.enterLocalPassiveMode();
                MostrarRespuestasFTP();

                do {
                    int opcion = MostrarMenuInicio();

                    switch (opcion) {
                        case 1:
                            ListarContenido();
                            break;
                        case 2:
                            EntrarDirectorio();
                            break;
                        case 3:
                            SubirFichero();
                            break;
                        case 4:
                            CrearDirectorio();
                            break;
                        case 5:
                            VolverHome();
                            break;
                        case 6:
                            finPrograma = true;
                            break;
                    }
                } while (!finPrograma);
                //cierra la conexión con el Servidor
                clienteFTP.disconnect();
                System.out.println("\n>>> CONEXIÓN FINALIZADA\n");
                System.out.println("********** ADIOS **********");
            } else {
                //desconecta
                clienteFTP.disconnect();
                System.err.println("El FTP ha rechazado la conexión esblecida");
                System.exit(1);
            }
        } catch (SocketException ex) {
            //error de Socket
            System.out.println(ex.toString());
        } catch (IOException ex) {
            //error de fichero
            System.out.println(ex.toString());
        }
    }

    private static int MostrarMenuInicio() {
        int opcion;

        do {
            System.out.print("""
                             
                             (1) Listar contenido
                             (2) Entrar directorio
                             (3) Subir fichero
                             (4) Crear un directorio
                             (5) Volver al home
                             (6) Salir
                             Elija una de las opciones:""");

            opcion = scanner.nextInt();
        } while (opcion < 1 && opcion > 6);

        return opcion;
    }

    public void LeerProperties() {
        Properties properties = new Properties();

        try {
            // Carga el fichero de properties
            properties.load(new FileInputStream("src/main/resources/configuracion.properties"));

            // El metodo fet devuelve un Object al guardarlo hay que hacer un casting
            usuario = (String) properties.getProperty("ftp.usuario");
            password = (String) properties.getProperty("ftp.password");
        } catch (FileNotFoundException ex) {
            ex.printStackTrace();
        } catch (IOException ex) {
            // Error de fichero
            ex.printStackTrace();
        }
    }


    private static void MostrarRespuestasFTP() {
        for (String respuesta : clienteFTP.getReplyStrings()) {
            System.out.println(respuesta);
        }
    }

    private static void ListarContenido() {
        try {
            System.out.println("");

            // Obtiene el listado de directorios
            String[] listadoCarpetas = clienteFTP.listNames();
            MostrarRespuestasFTP();

            // Lista las carpetas de primer nivel del servidor FTP
            System.out.println("\nCarpetas disponibles en " + clienteFTP.printWorkingDirectory() + ":");

            if (listadoCarpetas.length == 0) {
                System.out.println("Directorio vacío.");
            } else {
                for (int i = 0; i < listadoCarpetas.length; i++) {
                    System.out.println(listadoCarpetas[i]);
                }
            }
        } catch (IOException ex) {
            //error de fichero
            System.out.println(ex.toString());
        }
    }

    private static void EntrarDirectorio() {
        try {
            // Pide la ruta del directorio al usuario
            System.out.println("\nIntroduce el nombre del directorio al que desea acceder: ");
            String directorio = scanner.next();
            System.out.println("");

            // Cambia el directorio en el FTP
            clienteFTP.changeWorkingDirectory(directorio);
            MostrarRespuestasFTP();

            if (FTPReply.isPositiveCompletion(clienteFTP.getReplyCode())) {
                System.out.println("\nDirectorio actual: " + directorio);
            } else {
                System.out.println("\nEl directorio introducido no existe.");
            }
        } catch (IOException ex) {
            //error de fichero
            System.out.println(ex.toString());
        }
    }

    private static void SubirFichero() {
        try {
            // Pide la ruta del directorio al usuario
            System.out.println("\nIntroduce el nombre del fichero que desea subir: ");
            String nombreFichero = scanner.next();

            if (nombreFichero.length() != 0) {
                // Obtiene el nombre del directorio
                File fichero = new File(nombreFichero);
                System.out.println("");

                if (fichero == null || !fichero.exists() || fichero.isDirectory()) {
                    System.out.println("\n\nTiene que escribir un nombre válido.");
                } else {
                    // Obtiene el fichero
                    clienteFTP.setFileType(FTPClient.BINARY_FILE_TYPE);

                    System.out.println("\n\nSubiendo el fichero: " + fichero.getName());

                    // Sube el fichero al FTP
                    clienteFTP.storeFile(fichero.getName(), new FileInputStream(fichero));
                    MostrarRespuestasFTP();

                    if (FTPReply.isPositiveCompletion(clienteFTP.getReplyCode())) {
                        System.out.println("\n\nFichero: " + fichero.getName() + "subido correctamente.");
                    } else {
                        System.out.println("\n\nEl fichero no se ha podido subir.");
                    }
                }
            }
        } catch (IOException ex) {
            //error de fichero
            System.out.println(ex.toString());
        }
    }

    private static void CrearDirectorio() {
        try {
            // Pide la ruta del directorio al usuario
            System.out.println("\nIntroduce el nombre del directorio que desea crear: ");
            String directorioNuevo = scanner.next();
            System.out.println("");

            // Crea el directorio en el FTP
            clienteFTP.mkd(directorioNuevo);
            MostrarRespuestasFTP();

            if (FTPReply.isPositiveCompletion(clienteFTP.getReplyCode())) {
                System.out.println("\nDirectorio " + directorioNuevo + "creado correctamente.");
            } else {
                System.out.println("\nEl directorio introducido no se puede crear.");
            }
        } catch (IOException ex) {
            //error de fichero
            System.out.println(ex.toString());
        }
    }

    private static void VolverHome() {
        try {
            System.out.println("");
            // Cambia el directorio en el FTP
            clienteFTP.changeToParentDirectory();
            MostrarRespuestasFTP();
            System.out.println("\nDirectorio actual: " + clienteFTP.printWorkingDirectory());

        } catch (IOException ex) {
            //error de fichero
            System.out.println(ex.toString());
        }
    }
}
