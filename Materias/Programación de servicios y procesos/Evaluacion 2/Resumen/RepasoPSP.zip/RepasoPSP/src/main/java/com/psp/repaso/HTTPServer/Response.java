package com.psp.repaso.HTTPServer;

public class Response {
    private String status;
    private String headers;
    private String body;

    public Response(String status, String headers, String body) {
        this.status = status;
        this.headers = headers;
        this.body = body;
    }

    public String getStatus() {
        return status;
    }

    public String getHeaders() {
        return headers;
    }

    public String getBody() {
        return body;
    }
}