package com.psp.repaso;

import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.io.FileOutputStream;
import java.security.Signature;
import java.security.*;

public class Ficheros {
    public static byte[] leerFicheroComoBytes(String fichero) {
        try {
            return Files.readAllBytes(Paths.get(fichero));
        } catch (IOException e) {
            System.err.println("Error al leer el fichero: " + fichero);
            return null;
        }
    }

    public static String leerFicheroComoString(String fichero) {
        byte[] datos = leerFicheroComoBytes(fichero);
        if (datos != null) return new String();
        return null;
    }

    // Método que guarda datos en un fichero con caracteres
    public static boolean escribirFicheroEnCaracteres(String datos, String nombreFichero, boolean sobreescribir) {
        try {
            // Crea un FileWriter para escribir en el archivo
            FileWriter writer = new FileWriter(nombreFichero, !sobreescribir);

            // Escribe datos en el archivo
            writer.write(datos); // Convirtiendo el byte[] a String para escribirlo en el archivo

            // Cierra el archivo
            writer.close();

            // Muestra mensaje de éxito
            System.out.println("Fichero creado correctamente: " + nombreFichero);
            return true;
        } catch (IOException e) {
            System.out.println("ERROR AL ESCRIBIR LOS DATOS EN EL NUEVO FICHERO." + e.getMessage());
            return false;
        }
    }

    // Método que guarda datos en un fichero binario
    public static boolean escribirFicheroEnBinario(byte[] datos, String nombreFichero, boolean sobreescribir) {
        try {
            // Crea un FileWriter para escribir en el archivo
            FileOutputStream fichero = new FileOutputStream(nombreFichero, !sobreescribir);

            // Escribe la firma en el archivo
            fichero.write(datos); // Convirtiendo el byte[] a String para escribirlo en el archivo

            // Cierra el archivo
            fichero.close();

            // Muestra mensaje de éxito
            System.out.println("Fichero creado correctamente: " + nombreFichero);
            return true;
        } catch (IOException e) {
            System.out.println("ERROR AL ESCRIBIR LOS DATOS EN EL NUEVO FICHERO." + e.getMessage());
            return false;
        }
    }
}
