package com.psp.repaso.cifrado;

import java.security.*;

import static com.psp.repaso.Styles.ANSI_RED;
import static com.psp.repaso.Styles.ANSI_RESET;

public class FirmaAsimetrica {
    /*================ ATRIBUTOS DE CLASE ================*/
    public static final String[] ALGORITMOs = {"DSA", "RSA"};
    public static final int LONGITUD_CLAVE = 512;

    /*================ ATRIBUTOS DE OBJETO ================*/
    private PrivateKey clavePrivada;
    private PublicKey clavePublica;
    private KeyPairGenerator keyGen;
    private String algoritmo;
    private int longitudClave;

    /*================ CONSTRUCTORES ================*/
    public FirmaAsimetrica(String algoritmo) throws NoSuchAlgorithmException {
        this.algoritmo = algoritmo;
        this.clavePrivada = clavePrivada;
        keyGen = KeyPairGenerator.getInstance(algoritmo);
    }

    /*================ MÉTODOS ================*/
    public void generarClaves(int longitudClave, String semilla) {
        this.longitudClave = longitudClave;
        if (semilla != null) {
            keyGen.initialize(longitudClave, new SecureRandom(semilla.getBytes()));
        } else {
            keyGen.initialize(longitudClave);
        }
        KeyPair parClaves = keyGen.generateKeyPair();
        clavePrivada = parClaves.getPrivate();
        clavePublica = parClaves.getPublic();
    }

    public void generarClaves(int longitudClave) {
        generarClaves(longitudClave, null);
    }

    public String getAlgoritmo() {
        return algoritmo;
    }

    public void setAlgoritmo(String algoritmo) {
        try {
            keyGen = KeyPairGenerator.getInstance(algoritmo);
            this.algoritmo = algoritmo;
        } catch (NoSuchAlgorithmException e) {
            System.out.println(ANSI_RED + "El algoritmo no es válido" + ANSI_RESET);
        }
    }

    public PrivateKey getClavePrivada() {
        return clavePrivada;
    }

    public void setClavePrivada(PrivateKey clavePrivada) {
        this.clavePrivada = clavePrivada;
    }

    public PublicKey getClavePublica() {
        return clavePublica;
    }

    public void setClavePublica(PublicKey clavePublica) {
        this.clavePublica = clavePublica;
    }

    // Método que realiza la firma digital del fichero con DSA y la devuelve
    public byte[] firmarFicheroAsincrono(byte[] datos) {
        byte[] firmado = null;

        try {
            // Crea el objeto tipo Signature con algoritmo especificado
            Signature firma = Signature.getInstance(algoritmo);

            // Inicializa la firma con la clave privada a utilizar
            firma.initSign(clavePrivada);

            // Obtiene el resumen del mensaje
            firma.update(datos);

            // Obtiene la firma digital
            firmado = firma.sign();
            System.out.println("Firma: " + firmado.toString());
        } catch (Exception e) {
            System.out.println("ERROR AL FIRMAR EL FICHERO." + e.getMessage());
        }

        // Devuleve la firma digital
        return firmado;
    }

    // Método que verifica la firma digital, devolviendo:
    // >>> FALSO, si la firma no es correcta o se produce una excepción
    // >>> VERDADERO, si la firma es correcta
    public boolean verificarFirmaAsincrono(byte[] texto, byte[] textoFirmado) {
        try {
            // Crea el objeto tipo Signature con algoritmo DSA
            Signature firma = Signature.getInstance(algoritmo);

            // Verifica la clave pública
            firma.initVerify(clavePublica);

            // Actualiza el resumen de mensaje original
            firma.update(texto);

            // Devuelve el resultado de la verificación
            boolean firmaCorrecta = firma.verify(textoFirmado);
            return firmaCorrecta;
        } catch (Exception e) {
            System.out.println(ANSI_RED + "Firma no verificada" + ANSI_RESET);
        }
        return false;
    }
}
