package com.psp.repaso.cifrado;

import com.psp.repaso.Ficheros;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import java.io.FileWriter;
import java.io.IOException;
import java.security.*;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;

import static com.psp.repaso.Styles.ANSI_RED;
import static com.psp.repaso.Styles.ANSI_RESET;

public class CifradoAsimetrico {
    /*================ ATRIBUTOS DE CLASE ================*/
    public static final String[] ALGORITMOs = {"DSA", "RSA"};
    public static final int LONGITUD_CLAVE = 512;

    /*================ ATRIBUTOS ================*/
    private PrivateKey clavePrivada;
    private PublicKey clavePublica;
    private KeyPairGenerator keyGen;
    private String algoritmo;
    private int longitudClave;

    /*================ CONSTRUCTORES ================*/
    public CifradoAsimetrico(String algoritmo, int longitudClave) throws NoSuchAlgorithmException {
        this.algoritmo = algoritmo;
        this.clavePrivada = clavePrivada;
        keyGen = KeyPairGenerator.getInstance(algoritmo);
        this.longitudClave = longitudClave;
        keyGen.initialize(longitudClave);
    }

    public void generarClaves(int longitudClave, String semilla) {
        this.longitudClave = longitudClave;
        if (semilla != null) {
            keyGen.initialize(longitudClave, new SecureRandom(semilla.getBytes()));
        } else {
            keyGen.initialize(longitudClave);
        }
        KeyPair parClaves = keyGen.generateKeyPair();
        clavePrivada = parClaves.getPrivate();
        clavePublica = parClaves.getPublic();
    }

    public void generarClaves(int longitudClave) {
        generarClaves(longitudClave, null);
    }

    public String getAlgoritmo() {
        return algoritmo;
    }

    public void setAlgoritmo(String algoritmo) {
        this.algoritmo = algoritmo;
        try {
            keyGen = KeyPairGenerator.getInstance(algoritmo);
        } catch (NoSuchAlgorithmException e) {
            System.out.println(ANSI_RED + "El algoritmo no es válido" + ANSI_RESET);
        }
    }

    public PrivateKey getClavePrivada() {
        return clavePrivada;
    }

    public void setClavePrivada(PrivateKey clavePrivada) {
        this.clavePrivada = clavePrivada;
    }

    public PublicKey getClavePublica() {
        return clavePublica;
    }

    public void setClavePublica(PublicKey clavePublica) {
        this.clavePublica = clavePublica;
    }

    public PublicKey leerClavePublica(String fichero) {
        // Lee el fichero
        byte[] clavePublicaBytes = Ficheros.leerFicheroComoBytes(fichero);

        if (clavePublicaBytes == null) return null;

        // Elimina las cabeceras y los saltos de línea
        String clavePublicaString = new String(clavePublicaBytes);
        clavePublicaString = clavePublicaString.replace("--BEGIN " + algoritmo + " PUBLIC KEY--", "")
                .replace("--END " + algoritmo + " PUBLIC KEY--", "")
                .replace("\n", "");

        // Decodifica la clave pública en bytes
        clavePublicaBytes = Base64.getDecoder().decode(clavePublicaString);

        // Obtiene la clave pública
        PublicKey clavePublica = null;
        try {
            KeyFactory keyFactory = KeyFactory.getInstance(algoritmo);
            X509EncodedKeySpec publicKeySpec = new X509EncodedKeySpec(clavePublicaBytes);
            clavePublica = keyFactory.generatePublic(publicKeySpec);
        } catch (NoSuchAlgorithmException e) {
            System.out.println(ANSI_RED + "El algoritmo no es válido" + ANSI_RESET);
        } catch (InvalidKeySpecException e) {
            System.out.println(ANSI_RED + "La clave pública no es válida" + ANSI_RESET);
        }

        // Devuelve la clave pública
        return clavePublica;
    }

    public PrivateKey leerClavePrivada(String fichero) {
        // Lee el fichero
        byte[] clavePrivadaBytes = Ficheros.leerFicheroComoBytes(fichero);

        if (clavePrivadaBytes == null) return null;

        // Elimina las cabeceras y los saltos de línea
        String clavePrivadaString = new String(clavePrivadaBytes);
        clavePrivadaString = clavePrivadaString.replace("--BEGIN " + algoritmo + " PRIVATE KEY--", "")
                .replace("--END " + algoritmo + " PRIVATE KEY--", "")
                .replace("\n", "");

        // Decodifica la clave privada en bytes
        clavePrivadaBytes = Base64.getDecoder().decode(clavePrivadaString);

        // Obtiene la clave privada
        PrivateKey clavePrivada = null;
        try {
            KeyFactory keyFactory = KeyFactory.getInstance(algoritmo);
            X509EncodedKeySpec privateKeySpec = new X509EncodedKeySpec(clavePrivadaBytes);
            clavePrivada = keyFactory.generatePrivate(privateKeySpec);
        } catch (NoSuchAlgorithmException e) {
            System.out.println(ANSI_RED + "El algoritmo no es válido" + ANSI_RESET);
        } catch (InvalidKeySpecException e) {
            System.out.println(ANSI_RED + "La clave privada no es válida" + ANSI_RESET);
        }

        // Devuelve la clave privada
        return clavePrivada;
    }

    public void cargarClavePublica(String fichero) {
        clavePublica = leerClavePublica(fichero);
    }

    public void cargarClavePrivada(String fichero) {
        clavePrivada = leerClavePrivada(fichero);
    }

    private boolean guardarClavePublica(String nombreFichero) {
        // Guardar la clave pública
        StringBuilder contenido = new StringBuilder();
        contenido.append("--BEGIN " + algoritmo + " PUBLIC KEY--\n");
        contenido.append(Base64.getEncoder().encodeToString(clavePublica.getEncoded()));
        contenido.append("\n--END " + algoritmo + " PUBLIC KEY--\n");

        if (Ficheros.escribirFicheroEnCaracteres(contenido.toString(), nombreFichero, false)) {
            System.out.println("Clave pública guardada correctamente en " + nombreFichero);
            return true;
        } else {
            System.out.println(ANSI_RED + "Error al guardar la clave pública" + ANSI_RESET);
            return false;
        }
    }

    public boolean guardarClavePrivada(String nombreFichero) {
        // Guardar la clave privada
        StringBuilder contenido = new StringBuilder();
        contenido.append("--BEGIN " + algoritmo + " PRIVATE KEY--\n");
        contenido.append(Base64.getEncoder().encodeToString(clavePrivada.getEncoded()));
        contenido.append("\n--END " + algoritmo + " PRIVATE KEY--\n");

        if (Ficheros.escribirFicheroEnCaracteres(contenido.toString(), nombreFichero, false)) {
            System.out.println("Clave privada guardada correctamente en " + nombreFichero);
            return true;
        } else {
            System.out.println(ANSI_RED + "Error al guardar la clave pública" + ANSI_RESET);
            return false;
        }
    }

    public byte[] cifrar(byte[] datos) {
        try {
            Cipher cifrador = Cipher.getInstance(algoritmo);
            cifrador.init(Cipher.ENCRYPT_MODE, clavePublica);
            return cifrador.doFinal(datos);
        } catch (NoSuchAlgorithmException e) {
            System.out.println(ANSI_RED + "El algoritmo no es válido" + ANSI_RESET);
        } catch (NoSuchPaddingException e) {
            System.out.println(ANSI_RED + "El relleno no es válido" + ANSI_RESET);
        } catch (IllegalBlockSizeException e) {
            System.out.println(ANSI_RED + "El tamaño de bloque no es válido" + ANSI_RESET);
        } catch (BadPaddingException e) {
            System.out.println(ANSI_RED + "El relleno no es válido" + ANSI_RESET);
        } catch (InvalidKeyException e) {
            System.out.println(ANSI_RED + "La clave privada no es válida" + ANSI_RESET);
        }

        // En caso de fallos, devuelve null
        return null;
    }

    public byte[] descifrar(byte[] datos) { // throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException
        try {
            Cipher cifrador = Cipher.getInstance(algoritmo);
            cifrador.init(Cipher.DECRYPT_MODE, clavePrivada);
            return cifrador.doFinal(datos);
        } catch (NoSuchAlgorithmException e) {
            System.out.println(ANSI_RED + "El algoritmo no es válido" + ANSI_RESET);
        } catch (NoSuchPaddingException e) {
            System.out.println(ANSI_RED + "El relleno no es válido" + ANSI_RESET);
        } catch (IllegalBlockSizeException e) {
            System.out.println(ANSI_RED + "El tamaño de bloque no es válido" + ANSI_RESET);
        } catch (BadPaddingException e) {
            System.out.println(ANSI_RED + "El relleno no es válido" + ANSI_RESET);
        } catch (InvalidKeyException e) {
            System.out.println(ANSI_RED + "La clave privada no es válida" + ANSI_RESET);
        }

        // En caso de fallos, devuelve null
        return null;
    }
}
