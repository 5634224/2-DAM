package com.psp.repaso.correo;

import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.mail.search.FlagTerm;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Email {
    /*========================= CAMPOS =========================*/
    /* Campos comunes a todos los emails */
    private String asunto;
    private String contenido;
    private String destinatario;
    private String remitente;
    private boolean leido;
    private boolean favorito;
    private ArrayList<MimeBodyPart> adjuntos;

    /* Campos propios para enviar correos */
    private Session sesionSMTP;

    /* Campos propios para recibir correos */
    private Session sesionIMAP;

    /*========================= CONSTRUCTORES =========================*/
    public Email(String asunto, String contenido, String destinatario, String remitente) {
        this.asunto = asunto;
        this.contenido = contenido;
        this.destinatario = destinatario;
        this.remitente = remitente;
    }

    public Email(Email email) {
        this(email.asunto, email.contenido, email.destinatario, email.remitente);
    }

    public Email(Message mensaje) throws MessagingException, IOException {
        this(mensaje.getSubject(), mensaje.getContent().toString(), mensaje.getRecipients(Message.RecipientType.TO)[0].toString(), mensaje.getFrom()[0].toString());
    }

    public Email() {
        this("", "", "", "");
    }

    /*========================= MÉTODOS =========================*/
    public void setSesionIMAP(Session sesionIMAP) {
        this.sesionIMAP = sesionIMAP;
    }

    public Session getSesionIMAP() {
        return sesionIMAP;
    }

    public void setSesionSMTP(Session sesionSMTP) {
        this.sesionSMTP = sesionSMTP;
    }

    public Session getSesionSMTP() {
        return sesionSMTP;
    }

    public String getAsunto() {
        return asunto;
    }

    public void setAsunto(String asunto) {
        if (!this.asunto.equals(asunto)) {
            this.asunto = asunto;
        }
    }

    public String getContenido() {
        return contenido;
    }

    public void setContenido(String contenido) {
        if (!this.contenido.equals(contenido)) {
            this.contenido = contenido;
        }
    }

    public String getDestinatario() {
        return destinatario;
    }

    public void setDestinatario(String destinatario) {
        if (!this.destinatario.equals(destinatario)) {
            this.destinatario = destinatario;
        }
    }

    public String getRemitente() {
        return remitente;
    }

    public void setRemitente(String remitente) {
        if (!this.remitente.equals(remitente)) {
            this.remitente = remitente;
        }
    }

    public boolean isLeido() {
        return leido;
    }

    public void setLeido(boolean leido) {
        if (leido != this.leido) {
            this.leido = leido;
        }
    }

    public boolean isFavorito() {
        return favorito;
    }

    public void setFavorito(boolean favorito) {
        if (favorito != this.favorito) {
            this.favorito = favorito;
        }
    }

    /*========================= MÉTODOS PROPIOS PARA ENVIAR CORREOS =========================*/
    public MimeBodyPart getAdjunto(int indice) {
        return adjuntos.get(indice);
    }

    private boolean esAdjunto(BodyPart bodyPart) throws MessagingException {
        // Verificar si tiene disposición "attachment"
        String disposicion = bodyPart.getDisposition();
        if (disposicion != null && (disposicion.equalsIgnoreCase(BodyPart.ATTACHMENT) || disposicion.equalsIgnoreCase(BodyPart.INLINE))) {
            return true;
        }

        // Verificar si tiene tipo de contenido que generalmente indica un archivo adjunto
        String tipoContenido = bodyPart.getContentType();
        if (tipoContenido != null && tipoContenido.toLowerCase().startsWith("application/")) {
            return true;
        }

        return false;
    }

    public void addFicheroAdjunto(String ruta) throws MessagingException, IOException {
        MimeBodyPart adjunto = new MimeBodyPart();
        adjunto.attachFile(ruta);
        this.adjuntos.add(adjunto);
    }

    public void addFicheroAdjunto(MimeBodyPart adjunto) throws MessagingException, IOException {
        this.adjuntos.add(adjunto);
    }

    public void removeFicheroAdjunto(int indice) {
        this.adjuntos.remove(indice);
    }

    public void removeFicheroAdjunto(MimeBodyPart adjunto) {
        this.adjuntos.remove(adjunto);
    }

    public void removeFicheroAdjunto(String nombre) throws MessagingException {
        for (MimeBodyPart adjunto : this.adjuntos) {
            if (adjunto.getFileName().equals(nombre)) {
                this.adjuntos.remove(adjunto);
                break;
            }
        }
    }

    public int countAdjuntos() {
        return this.adjuntos.size();
    }

    public void clearFicherosAdjuntos() {
        this.adjuntos.clear();
    }

    public void sendEmail() throws MessagingException {
        MimeMessage message = new MimeMessage(sesionSMTP);
        message.setFrom(new InternetAddress(getRemitente()));
        message.addRecipient(Message.RecipientType.TO, new InternetAddress(getDestinatario()));
        message.setSubject(getAsunto());
        Multipart multipart = new MimeMultipart();

        // Agregar el contenido del mensaje
        MimeBodyPart messageBodyPart = new MimeBodyPart();
        messageBodyPart.setContent(getContenido(), "text/html");
        multipart.addBodyPart(messageBodyPart);

        // Agregar los adjuntos
        if (adjuntos != null && !adjuntos.isEmpty()) {
            for (MimeBodyPart adjunto : adjuntos) {
                multipart.addBodyPart(adjunto);
            }
            message.setContent(multipart);
        }

        // Enviar el mensaje
        message.setContent(multipart);
        Transport.send(message);
    }

    /*========================= MÉTODOS PROPIOS PARA RECIBIR CORREOS =========================*/
    public void recibirEmail(Message mensaje) throws MessagingException, IOException {
        this.asunto = mensaje.getSubject();
        this.contenido = mensaje.getContent().toString();
        this.destinatario = mensaje.getRecipients(Message.RecipientType.TO)[0].toString();
        this.remitente = mensaje.getFrom()[0].toString();
    }

    public static List<Email> leerEmailsDestacados(Session sesionIMAP, String user, String password) throws MessagingException, IOException {
        List<Email> emails = new ArrayList<Email>();

        // Conectarse al servidor IMAP
        Store store = sesionIMAP.getStore("imaps");

        store.connect(sesionIMAP.getProperty("mail.imap.host"), user, password);

        // Obtener la carpeta "Inbox"
        Folder inbox = store.getFolder("Inbox");
        inbox.open(Folder.READ_ONLY); // Abre la carpeta en modo solo lectura

        // Obtener los mensajes destacados
        FlagTerm ft = new FlagTerm(new Flags(Flags.Flag.FLAGGED), true); // Mensajes destacados
        Message[] messagesDestacados = inbox.search(ft);

        for (Message message : messagesDestacados) {
            Email email = new Email();
            Multipart multipart = (Multipart) message.getContent();
            BodyPart bodyPart = multipart.getBodyPart(0);

            email.setAsunto(message.getSubject());
            email.setContenido(bodyPart.getContent().toString());
            email.setDestinatario(Arrays.toString(message.getRecipients(Message.RecipientType.TO)));
            email.setRemitente(message.getFrom()[0].toString());
            email.setLeido(message.getFlags().contains(Flags.Flag.SEEN));
            email.setFavorito(message.getFlags().contains(Flags.Flag.FLAGGED));
            email.setSesionIMAP(sesionIMAP);

            // Añade el email a la lista
            emails.add(email);
        }

        // Cierre de la carpeta y del store
        inbox.close(false);
        store.close();

        // Devuelve los mensajes destacados
        return emails;
    }

    public static int countEmailsNoLeidos(Session sesionIMAP, String user, String password) throws MessagingException, IOException {
        // Conectarse al servidor IMAP
        Store store = sesionIMAP.getStore("imaps");
        store.connect(sesionIMAP.getProperty("mail.imap.host"), user, password);

        // Obtener la carpeta "Inbox"
        Folder inbox = store.getFolder("Inbox");
        inbox.open(Folder.READ_ONLY);

        // Obtencion del numero de correos sin leer
        int numeroCorreosSinLeer = inbox.getUnreadMessageCount();

        // Cierre de la carpeta y del store
        inbox.close(false);
        store.close();

        // Devuelve el numero de correos sin leer
        return numeroCorreosSinLeer;
    }
}