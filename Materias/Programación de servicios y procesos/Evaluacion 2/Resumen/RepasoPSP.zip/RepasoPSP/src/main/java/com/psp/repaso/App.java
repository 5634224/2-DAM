package com.psp.repaso;

public class App {

    /*================ MÉTODO MAIN ================*/
    public static void main(String[] args) {
        System.out.println("Hello world!");
    }
}

/*
Todo lo que puede entrar:
-Expresiones regulares (lo típico: un login) -> hecho
-Logs (Log4J) -> hecho
-Clases URL -> hecho
-Ficheros properties -> hecho
-FTP -> hecho
-HTTP (cabeceras) -> hecho
-Correo (IMAP y SMTP) -> hecho
-Hasheado (MessageDigest) -> hecho
-Cifrado (simetrico y asimetrico)
-Firma (es asimétrico siempre) -> hecho
*/