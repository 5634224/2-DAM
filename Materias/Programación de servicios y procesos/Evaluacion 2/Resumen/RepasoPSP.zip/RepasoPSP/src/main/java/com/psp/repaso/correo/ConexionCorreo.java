package com.psp.repaso.correo;

import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;
import java.util.Properties;
import java.util.Scanner;

public class ConexionCorreo {
    // Creacion del objeto para la lectura de la entrada estandar
    private static Scanner scanner = new Scanner(System.in);
    private static Properties properties;
    private Session sessionSMTP;
    private Session sessionIMAP;

    // Credenciales de correo electrónico
    private static String correo; // Dirección de correo del destinatario
    private static String password; // Contraseña del correo del usuario

    public ConexionCorreo() {
        boolean finPrograma = false;

        LeerProperties();

        // Configura la sesion SMTP
        Properties propsSMTP = new Properties();
        propsSMTP.put("mail.smtp.host", "smtp.gmail.com");
        propsSMTP.put("mail.smtp.socketFactory.port", "465");
        propsSMTP.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
        propsSMTP.put("mail.smtp.auth", "true");
        propsSMTP.put("mail.smtp.port", "465");

        // Configura la sesion SMTP
        this.sessionSMTP = Session.getDefaultInstance(propsSMTP,
                new Authenticator() {
                    @Override
                    protected PasswordAuthentication getPasswordAuthentication() {
                        return new PasswordAuthentication(correo, password);
                    }
                });

        // Configura la sesion IMAP
        Properties propsIMAP = new Properties();
        propsIMAP.put("mail.imap.host", "imap.gmail.com");
        propsIMAP.put("mail.imap.port", "993");
        propsIMAP.put("mail.imap.starttls.enable", "true");
        propsIMAP.put("mail.imap.ssl.trust", "imap.gmail.com");
        propsIMAP.put("mail.imap.auth", "true");

        // Configura la sesion IMAP
        this.sessionIMAP = Session.getInstance(propsIMAP,
                new Authenticator() {
                    @Override
                    protected PasswordAuthentication getPasswordAuthentication() {
                        return new PasswordAuthentication(correo, password);
                    }
                });

        do {
            int opcion = MostrarMenuInicio();

            switch (opcion) {
                case 1:
                    try {
                        List<Email> correos = Email.leerEmailsDestacados(sessionIMAP, correo, password);

                        for(Email email : correos) {
                            // Se muestran los datos de los correos
                            System.out.println(email.getContenido());
                        }
                    }
                    catch (MessagingException e) {
                        System.out.println(e.getMessage());
                    }
                    catch(IOException e){
                        System.out.println(e.getMessage());
                    }

                    break;
                case 2:
                    Email email = new Email("Prueba", "Esto es un mensaje de prueba", "prueba@gmail.com", correo);
                    try {
                        email.setSesionSMTP(sessionSMTP);
                        email.sendEmail();
                    } catch (MessagingException e){
                        System.out.println(e.getMessage());
                    }
                    //EnviarCorreo("prueba@gmail.com", "Prueba", "Esto es un mensaje de prueba");
                    break;
                case 3:
                    try {
                        Email.countEmailsNoLeidos(sessionSMTP, correo, password);
                    }
                    catch (MessagingException e) {
                        System.out.println(e.getMessage());
                    }
                    catch(IOException e){
                        System.out.println(e.getMessage());
                    }
                    //ActualizarBandejaEntrada();
                    break;
                case 4:
                    finPrograma = true;
                    break;
            }
        } while (!finPrograma);
    }

    private static int MostrarMenuInicio() {
        int opcion;

        do {
            System.out.print("""
                             
                             (1) Leer bandeja destacados
                             (2) Enviar Correo
                             (3) Leer correos no leidos
                             (4) Salir
                             Elija una de las opciones:""");

            opcion = scanner.nextInt();
        } while (opcion < 1 && opcion > 6);

        return opcion;
    }

    private void LeerProperties(){
        properties = new Properties();

        try {
            // Carga el fichero de properties
            properties.load(new FileInputStream("src/main/resources/configuracion.properties"));
//            properties.load(getClass().getClassLoader().getResourceAsStream("configuration.properties"));
            correo = (String) properties.getProperty("email.cuenta");
            password = (String) properties.getProperty("email.key");
        } catch (FileNotFoundException ex) {
            ex.getMessage();
        } catch (IOException ex) {
            // Error de fichero
            ex.getMessage();
        }
    }

    private void ActualizarBandejaEntrada() {
        try {
            // Obtiene el Store y conectarse al servidor IMAP
            Store store = sessionIMAP.getStore("imaps");
            store.connect(correo, password);
            System.out.println("\nCONEXION EXITOSA");

            // Obtiene la carpeta de la bandeja de entrada
            Folder inbox = store.getFolder("INBOX");
            inbox.open(Folder.READ_ONLY);

            // Cuenta los correos no leídos
            int correosNoLeidos = inbox.getUnreadMessageCount();
            System.out.println("Número de correos no leídos: " + correosNoLeidos);

            // Cierra la conexión
            inbox.close(false);
            store.close();
        } catch (Exception ex) {
            System.out.println("\n" + ex.getMessage() +
                    "\n" + ex.getLocalizedMessage());
        }
    }

    private void EnviarCorreo(String mailDestinatario, String asunto, String mensaje) {
        if (mailDestinatario.isEmpty() || mensaje.isEmpty() || asunto.isEmpty()) {
            System.out.println("No se puede enviar el mensaje, revise los datos introducidos.");
            return;
        }

        try {
            System.out.println("\nEnviando mensaje....");

            // Compone el mensaje
            MimeMessage correo = new MimeMessage(sessionSMTP);
            correo.setFrom(new InternetAddress(ConexionCorreo.correo));
            correo.setRecipients(MimeMessage.RecipientType.TO, InternetAddress.parse(mailDestinatario));

            // Asunto
            correo.setSubject(asunto);

            // Cuerpo del mensaje
            correo.setText(mensaje);

            // Envía el mensaje, realizando conexión, transmisión y desconexión
            Transport.send(correo);

            // Lo da por enviado
            System.out.println("Mensaje enviado!");
        } catch (MessagingException e) {
            System.out.println(e.getMessage());
        }
    }

}
