package com.psp.repaso.HTTPServer;

public class RequestHandler {
    public Response handle(Request request) {
        String html;
        if (request.getPath().length() == 0 || request.getPath().equals("/")) {
            html = Paginas.html_index;
            return new Response(Mensajes.lineaInicial_OK, Paginas.primeraCabecera, html);
        } else if (request.getPath().equals("/quijote")) {
            html = Paginas.html_quijote;
            return new Response(Mensajes.lineaInicial_OK, Paginas.primeraCabecera, html);
        } else {
            html = Paginas.html_noEncontrado;
            return new Response(Mensajes.lineaInicial_NotFound, Paginas.primeraCabecera, html);
        }
    }
}