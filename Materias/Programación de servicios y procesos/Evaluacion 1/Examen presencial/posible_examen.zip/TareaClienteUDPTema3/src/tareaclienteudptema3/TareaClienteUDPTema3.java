/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package tareaclienteudptema3;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.Socket;
import java.util.Scanner;

/**
 *
 * @author andre
 */
public class TareaClienteUDPTema3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        
        int serverPort = 2000;// Puerto del servidor UDP

        try {
            // Crear un socket UDP para el cliente
            Socket clienteSocket = new Socket("localhost",serverPort);
            
            DataInputStream dis = new DataInputStream(clienteSocket.getInputStream());
            DataOutputStream dos = new DataOutputStream(clienteSocket.getOutputStream());
            
            Scanner scanner = new Scanner(System.in);

            // Solicitar la longitud de la palabra al usuario
            System.out.print("Escribe la longitud de la palabra: ");
            String longitudStr = scanner.nextLine();
            scanner.close();

            dos.writeUTF(longitudStr);

            String respuesta = dis.readUTF();
            System.out.println("Respuesta del servidor: " + respuesta);            
                      
            clienteSocket.close();
            scanner.close();
            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
