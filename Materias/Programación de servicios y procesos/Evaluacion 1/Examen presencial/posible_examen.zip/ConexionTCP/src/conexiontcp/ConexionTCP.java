/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package conexiontcp;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.BindException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;

/**
 *
 * @author andre
 */
public class ConexionTCP {
    
    static int udpServerPort = 2023; // Puerto del servidor UDP
     
    public static void main(String[] args) {
      
        int intermediatePort = 2000; // Puerto del servidor intermedio (TCP)
        String udpServerAddress = "localhost";
        

        try {
            
            DatagramSocket udpSocket = new DatagramSocket(); // Crear el socket UDP fuera del bucle
            
            // Conectar con el servidor UDP          
            ServerSocket serverSocket = new ServerSocket(intermediatePort);
            System.out.println("Servidor intermedio TCP en espera...");

            while (true) {
                Socket clientSocket = serverSocket.accept();
                System.out.println("Cliente TCP conectado");
                
                DataInputStream dis = new DataInputStream(clientSocket.getInputStream());
                DataOutputStream dos = new DataOutputStream(clientSocket.getOutputStream());

                // Leer la longitud de la palabra desde el cliente TCP
                String length = dis.readUTF();
                System.out.println("Longitud proporcionada por el cliente " + length);
                 
                // Convertir la longitud en bytes y enviarla al servidor UDP
                byte[] lengthBytes = length.getBytes();
                InetAddress udpServerInetAddress = InetAddress.getByName(udpServerAddress);
                DatagramPacket sendPacket = new DatagramPacket(lengthBytes, lengthBytes.length, udpServerInetAddress, udpServerPort);
                udpSocket.send(sendPacket);

                // Recibir la respuesta del servidor UDP
                byte[] receiveData = new byte[1024];
                DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);
                udpSocket.receive(receivePacket);

                String udpResponse = new String(receivePacket.getData(), 0, receivePacket.getLength());

                // Enviar la respuesta al cliente TCP
                dos.writeUTF(udpResponse);

                clientSocket.close();
                System.out.println("Cliente desconectado");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}