/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package tareaudptema3;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.Random;

/**
 *
 * @author andre
 */
public class TareaUDPTema3 {

    static final int udpServerPort = 2023; // Puerto del servidor UDP
     
    public static void main(String[] args) {
        

        try {
            // Crear un socket UDP para el servidor
            DatagramSocket serverSocket = new DatagramSocket(udpServerPort);

            while (true) {
                System.out.println("El servidor UDP queda a la espera de peticiones");

                byte[] receiveData = new byte[1024];
                DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);
                serverSocket.receive(receivePacket);

                String mensaje = new String(receivePacket.getData(), 0, receivePacket.getLength());   
                System.out.println("Recibida petición de un cliente: " + mensaje);
                
                try {
                    // Intenta convertir la cadena de solicitud en un número entero
                    int longitud = Integer.parseInt(mensaje);                 

                    if (longitud < 0) {
                        System.out.println("No ha enviado una longitud válida");
                        mensaje = "No ha enviado una longitud válida";                       
                    } else {    
                        // Genera una palabra aleatoria y actualiza el mensaje
                        String palabraAleatoria = generateRandomWord(longitud);
                        mensaje = palabraAleatoria;
                        System.out.println("Es un número válido genero la palabra " + mensaje);

                    }
                } catch (NumberFormatException e) {
                    // Captura la excepción si no se pudo convertir la cadena en un número
                    System.out.println("No ha enviado una longitud válida");
                    mensaje = ("No ha enviado una longitud válida ");
                  
                }

                InetAddress clienteAddress = receivePacket.getAddress();
                int clientePort = receivePacket.getPort();
                byte[] sendData = mensaje.getBytes();
                DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, clienteAddress, clientePort);
                serverSocket.send(sendPacket);

            }

        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    // Genera una palabra aleatoria de la longitud especificada
    private static String generateRandomWord(int longitud) {
        String chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
        StringBuilder randomWord = new StringBuilder();

        Random random = new Random();
        for (int i = 0; i < longitud; i++) {
            char randomChar = chars.charAt(random.nextInt(chars.length()));
            randomWord.append(randomChar);
        }

        return randomWord.toString();
    }
}
   
