module ejemplo1 {
	requires javafx.graphics;
	requires javafx.fxml;
	requires javafx.controls;
	requires javafx.base;
	
	opens ch.makery.address.view;
	
	exports ch.makery.address;
	exports ch.makery.address.model;
	exports ch.makery.address.util;
	exports ch.makery.address.view;
}