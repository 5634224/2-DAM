package models;

public class MyModel {

	String saludo;
	
	public MyModel() {
		saludo = "HOLA";
	}
	
	public String getSaludo() {
		return saludo;
	}

}
