package com.example.fragments

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import androidx.fragment.app.Fragment
import com.example.fragments.fragments.FragmentDos
import com.example.fragments.fragments.FragmentUno

class MainActivity : AppCompatActivity()
{
    override fun onCreate(savedInstanceState: Bundle?)
    {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        //Se carga el FragmentUno
        cargarFragment(FragmentUno())

        var numFragment=1
        val btnCargar: Button = findViewById(R.id.button_cargar_fragment)

        btnCargar.setOnClickListener()
        {
            if (numFragment == 1)
            {
                cargarFragment(FragmentDos())
                numFragment = 2
            }
            else
            {
                cargarFragment(FragmentUno())
                numFragment = 1
            }
        }



    }

    //Cargar fragments
    private fun cargarFragment(fragment: Fragment)
    {
        val fragmentTransaction = supportFragmentManager.beginTransaction()
        fragmentTransaction.add(R.id.frameLayout, fragment)
        fragmentTransaction.commit()
    }




}


