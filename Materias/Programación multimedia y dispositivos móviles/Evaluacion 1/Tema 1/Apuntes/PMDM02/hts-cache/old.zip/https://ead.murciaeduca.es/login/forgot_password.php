<!DOCTYPE html>
<html  lang="es" xml:lang="es">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<title>Redireccionar</title>
</head><body><div style="margin-top: 3em; margin-left:auto; margin-right:auto; text-align:center;">Esta página debería redireccionar automáticamente. Si no ocurre nada, por favor utilice el enlace de continuar que aparece más abajo.<br /><a href="https://eduid.murciaeduca.es">Continuar</a></div></body></html>