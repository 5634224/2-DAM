package com.example.bnmenu

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.Toast
import com.example.bnmenu.fragments.FragmentHome
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.example.bnmenu.fragments.*

class MainActivity : AppCompatActivity()
{
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        //Asignamos la nueva ToolBar
        setSupportActionBar(findViewById(R.id.toolbar))

        //Cargamos el primer fragment
        supportFragmentManager.beginTransaction()
            .replace(R.id.contenedor, FragmentHome())
            .addToBackStack(null)
            .commit()

        val bnv: BottomNavigationView = findViewById(R.id.bottom_navigation)

        bnv.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.menu_item_home -> {

                    supportFragmentManager.beginTransaction()
                        .replace(R.id.contenedor, FragmentHome())
                        .addToBackStack(null)
                        .commit()


                    true
                }

                R.id.menu_item_list -> {

                    supportFragmentManager.beginTransaction()
                        .replace(R.id.contenedor, FragmentList())
                        .addToBackStack(null)
                        .commit()


                    true
                }

                R.id.menu_item_fav -> {

                    supportFragmentManager.beginTransaction()
                        .replace(R.id.contenedor, FragmentFav())
                        .addToBackStack(null)
                        .commit()


                    true
                }

                R.id.menu_item_location -> {

                    supportFragmentManager.beginTransaction()
                        .replace(R.id.contenedor, FragmentMaps())
                        .addToBackStack(null)
                        .commit()


                    true
                }

                else -> false

            }
        }

    }
    //ToolBar
    //Infla la ToolBar
    override fun onCreateOptionsMenu(menu: Menu?): Boolean
    {
        menuInflater.inflate(R.menu.top_app_bar, menu)
        return true
    }

    //Gestionar los eventos onClick sobre los elementos de la ToolBar
    override fun onOptionsItemSelected(item: MenuItem): Boolean
    {
        when (item.itemId)
        {
            R.id.action_overflow->{
                // Acción cuando se selecciona el primer elemento del menú
                return true
            }

            R.id.menu_option1 ->{

                Toast.makeText(this, "Has pulsado la opción A",
                    Toast.LENGTH_LONG).show()

                return true
            }

            R.id.menu_option2 ->{

                Toast.makeText(this, "Has pulsado la opción B",
                    Toast.LENGTH_LONG).show()

                return true
            }

            R.id.search ->{
                Toast.makeText(this, "Búsqueda no disponible",
                    Toast.LENGTH_LONG).show()

                return true
            }

            // Agrega más casos según tus necesidades
            else -> return super.onOptionsItemSelected(item)
        }
    }
}