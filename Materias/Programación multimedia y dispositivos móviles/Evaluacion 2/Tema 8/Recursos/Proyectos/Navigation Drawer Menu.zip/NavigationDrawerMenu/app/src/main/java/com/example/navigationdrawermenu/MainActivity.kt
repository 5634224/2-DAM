package com.example.navigationdrawermenu

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.widget.Toolbar
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.core.view.GravityCompat
import androidx.navigation.ui.AppBarConfiguration
import androidx.drawerlayout.widget.DrawerLayout
import androidx.fragment.app.Fragment
import androidx.navigation.findNavController
import androidx.navigation.ui.navigateUp
import androidx.navigation.ui.setupActionBarWithNavController
import androidx.navigation.ui.setupWithNavController
import com.example.navigationdrawermenu.fragments.FirstFragment
import com.example.navigationdrawermenu.fragments.SecondFragment
import com.google.android.material.navigation.NavigationView

class MainActivity : AppCompatActivity()
{

    private lateinit var appBarConfiguration: AppBarConfiguration

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val drawerLayout = findViewById<DrawerLayout>(R.id.drawer_layout)
        val navigationView: NavigationView = findViewById(R.id.nav_view)
        val toolbar: Toolbar = findViewById(R.id.toolbar)

        setSupportActionBar(toolbar)

        val navController = findNavController(R.id.nav_host_fragment) //Equivalente a FrameLayout
        // Menu lateral - Drawer Menu
        appBarConfiguration = AppBarConfiguration(setOf(R.id.nav_home,
            R.id.nav_gallery, R.id.nav_slideshow), drawerLayout)

        setupActionBarWithNavController(navController, appBarConfiguration)
        navigationView.setupWithNavController(navController)


        //Toggle y DrawerLayout
        val toggle = ActionBarDrawerToggle(
            this, drawerLayout, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close
        )
        drawerLayout.addDrawerListener(toggle)
        toggle.syncState()

        supportFragmentManager
            .beginTransaction()
            .replace(R.id.nav_host_fragment, FirstFragment())
            .addToBackStack(null)
            .commit()

       navigationView.setNavigationItemSelectedListener { menuItem ->
        // Maneja los eventos de clic en el ítem aquí
        // Por ejemplo, cambiar de fragmento o iniciar una nueva actividad
          when (menuItem.itemId)
           {
               R.id.nav_home -> {

                   supportFragmentManager
                       .beginTransaction()
                       .replace(R.id.nav_host_fragment, SecondFragment())
                       .addToBackStack(null)
                       .commit()

               }

               R.id.nav_gallery -> {

                   supportFragmentManager
                       .beginTransaction()
                       .replace(R.id.nav_host_fragment, FirstFragment())
                       .addToBackStack(null)
                       .commit()

               }

               else -> {}
           }

           drawerLayout.closeDrawer(GravityCompat.START)
           // Retorna true para mostrar que has manejado el evento de clic
           true
        }

        val callback = object : OnBackPressedCallback(true /* enabled by default */) {
            override fun handleOnBackPressed()
            {
                // Maneja el evento de ir hacia atrás aquí
                if (drawerLayout.isDrawerOpen(GravityCompat.START))
                {
                    drawerLayout.closeDrawer(GravityCompat.START)
                }
                else
                {
                    isEnabled = false
                    finish()
                }
            }
        }

        onBackPressedDispatcher.addCallback(this, callback)

    }

}


