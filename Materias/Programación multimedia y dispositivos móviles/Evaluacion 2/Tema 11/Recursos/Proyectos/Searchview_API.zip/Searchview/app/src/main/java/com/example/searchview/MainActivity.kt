package com.example.searchview

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.ProgressBar
import androidx.appcompat.app.AppCompatActivity
import android.widget.SearchView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.widget.Toolbar
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.constraintlayout.widget.ConstraintSet.Constraint
import androidx.constraintlayout.widget.ConstraintSet.Layout
import androidx.lifecycle.lifecycleScope
import androidx.navigation.Navigation
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.example.searchview.api.CountriesApiService
import com.example.searchview.api.CountryAPI
import com.example.searchview.api.CountryItem
import com.example.searchview.api.rv.CountryItemAPIAdapter
import com.example.searchview.rv.Country
import com.example.searchview.rv.CountryAdapter
import com.google.android.material.snackbar.Snackbar
import com.google.firebase.Firebase
import com.google.firebase.auth.ktx.auth
import com.google.firebase.firestore.firestore
import kotlinx.coroutines.tasks.await
import com.google.firebase.storage.FirebaseStorage
import kotlinx.coroutines.*
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class MainActivity: AppCompatActivity() {

    private lateinit var searchView: SearchView
    private lateinit var recyclerView: RecyclerView
    private lateinit var progressBar: ProgressBar
    private lateinit var allCountries: MutableList<Country>
    private lateinit var filteredCountries: MutableList<Country>
    //API
    private lateinit var allCountriesAPI: MutableList<CountryItem>
    private lateinit var filteredCountriesAPI: MutableList<CountryItem>
    private var opcion:Int = 0


    private lateinit var swipe: SwipeRefreshLayout

    object RetrofitInstance
    {
        private val retrofit by lazy {
            Retrofit.Builder()
                .baseUrl("https://restcountries.com/v3.1/subregion/")
                .addConverterFactory(GsonConverterFactory.create())
                .build()
        }

        val api: CountriesApiService by lazy {
            retrofit.create(CountriesApiService::class.java)
        }
    }

    // Access a Cloud Firestore instance from your Activity
    private val db = Firebase.firestore
    private val countries = db.collection("paises")

    //Acceso a la nube(storage) de Firebase
    val storage = FirebaseStorage.getInstance()
    val storageRef = storage.reference

    override fun onCreate(savedInstanceState: Bundle?)
    {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val toolbar: Toolbar = findViewById(R.id.toolbar2)
        setSupportActionBar(toolbar)

        searchView = findViewById(R.id.searchView)
        recyclerView = findViewById(R.id.recyclerView)
        progressBar = findViewById(R.id.progressBar)
        swipe = findViewById(R.id.swipe)



        GlobalScope.launch(Dispatchers.Main)
        {
            recyclerView.layoutManager = LinearLayoutManager(applicationContext)
            allCountries = mutableListOf()
            allCountriesAPI = mutableListOf()

            searchView.visibility = View.GONE
            // Mostrar la ProgressBar
            progressBar.visibility = View.VISIBLE
            progressBar.progress = 50

            //Elegimos entre Firebase y API Restful
            showOptionsDialog()

        }

        searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {

            override fun onQueryTextSubmit(query: String?): Boolean {
                return false
            }

            override fun onQueryTextChange(newText: String?): Boolean {
                filterCountries(newText)
                return true
            }
        })

        swipe.setOnRefreshListener {

            if (opcion == 1)
            {

                lifecycleScope.launch(Dispatchers.Main) {

                    allCountries.clear()

                    cargarPaises()

                    Toast.makeText(
                        applicationContext,
                        "Se detiene swipe", Toast.LENGTH_LONG
                    ).show()

                    filteredCountries.clear()
                    filteredCountries.addAll(allCountries)
                    recyclerView.adapter?.notifyDataSetChanged()

                    swipe.isRefreshing = false

                }
            }
            //La API no se actualiza con swipe
            else
            {
                swipe.isRefreshing = false
            }
        }

    }

    override fun onResume()
    {
        super.onResume()

        /*Especifica la referencia al documento que deseas monitorear
        val documentRef = countries.document("Argentina")

        // Agrega un snapshot listener para escuchar cambios en el documento
        val listener = documentRef.addSnapshotListener { snapshot, e ->
            if (e != null) {
                // Maneja cualquier error que pueda ocurrir
                return@addSnapshotListener
            }

            if (snapshot != null && snapshot.exists()) {
                // El documento existe, puedes verificar si ha sido actualizado
                //val data = snapshot.data // Obtén los datos del documento
                // Aquí puedes comparar los datos con la última versión que tienes
                // o realizar cualquier otra lógica para verificar si el documento ha sido actualizado

                Toast.makeText(
                    this,
                    "El documento ha sido modificado. Arrastra hacia abajo para actualizar la lista",
                    Toast.LENGTH_LONG
                ).show()

            } else {
                // El documento no existe
            }
        }*/
    }

    private fun filterCountries(query: String?) {
        filteredCountries.clear()

        if (query.isNullOrEmpty()) {
            filteredCountries.addAll(allCountries)
        } else {
            val lowercaseQuery = query.lowercase()
            filteredCountries.addAll(
                allCountries.filter { country ->
                    country.name.lowercase().contains(lowercaseQuery)
                }
            )
        }

        recyclerView.adapter?.notifyDataSetChanged()
    }

    private suspend fun cargarPaises()
    {

        withContext(Dispatchers.IO) {


            val docRef = countries.document("Argentina")

            try {
                docRef.get()
                    .addOnSuccessListener { document ->
                        if (document != null) {
                            var pais: Country =
                                Country(
                                    document.get("nombre").toString(),
                                    document.get("capital").toString(),
                                    document.get("bandera").toString()
                                )

                            allCountries.add(pais)

                            Toast.makeText(
                                applicationContext, "País añadido",
                                Toast.LENGTH_LONG
                            ).show()

                            /* Aquí podría colocar el adapter */

                        } else {
                            Log.d("Firebase", "No such document")
                        }
                    }.await()
            } catch (e: Exception) {
                println("exception: ${e.message}")
            }
        }
    }

    private suspend fun cargarPaisesAPI()
    {
            val call = RetrofitInstance.api.
                getCountryInfo("Northern Europe")

            if (call.isSuccessful)
            {
                val countries = call.body()!!

                countries.forEach {
                    allCountriesAPI.add(it)
                }

            }
            else
            {
                val mainLayout: SwipeRefreshLayout = findViewById(R.id.swipe)
                Snackbar.make(this,mainLayout,call.toString().substring(30), Snackbar.LENGTH_INDEFINITE
                ).show()
            }
    }

    private suspend fun showOptionsDialog()
    {
            // Crear un constructor de AlertDialog
            val builder = AlertDialog.Builder(this)

            // Configurar el título
            builder.setTitle("Elige una opción")

            // Configurar las opciones del diálogo
            builder.setItems(arrayOf("Opción 1 - Firebase", "Opción 2 - API Restful")) { dialog, which ->
                when (which) {
                    0 -> { // Opción 1 seleccionada
                        opcion = 1
                    }

                    1 -> { // Opción 2 seleccionada
                        opcion = 2
                    }
                }
            }.setOnDismissListener {
                // Este bloque se ejecuta cuando el diálogo se descarta,
                // independientemente de cómo se haya descartado.
                // Puedes realizar acciones adicionales aquí si es necesario.

                GlobalScope.launch(Dispatchers.Main)
                {

                    if (opcion == 1) {
                        //await hace que no se ejecuten las líneas a continuación, hasta finalizar esta tarea
                        cargarPaises()

                        // Ocultar la ProgressBar cuando la operación se completa
                        progressBar.visibility = View.GONE
                        searchView.visibility = View.VISIBLE

                        filteredCountries = allCountries.toMutableList()
                        val adapter = CountryAdapter(filteredCountries)
                        recyclerView.adapter = adapter
                    } else {
                        //await hace que no se ejecuten las líneas a continuación, hasta finalizar esta tarea
                        cargarPaisesAPI()

                        // Ocultar la ProgressBar cuando la operación se completa
                        progressBar.visibility = View.GONE
                        searchView.visibility = View.VISIBLE

                        filteredCountriesAPI = allCountriesAPI.toMutableList()
                        val adapter = CountryItemAPIAdapter(filteredCountriesAPI)
                        recyclerView.adapter = adapter
                    }
                }
            }

        withContext(Dispatchers.Main)
        {
            // Crear y mostrar el AlertDialog
            builder.create().show()
        }

    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.top_app_bar, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.menu_option1-> {

                // Initialize Firebase Auth
                val auth = com.google.firebase.ktx.Firebase.auth
                auth.signOut()

                //Saltar al  siguiente intent
                // Crear un Intent para iniciar MainActivity
                val intent = Intent(this, LoginActivity::class.java)
                // Iniciar LoginActivity
                startActivity(intent)

                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }
}

