package com.example.searchview.api

data class Fin(
    val common: String,
    val official: String
)