package com.example.searchview.api

data class Name(
    val common: String,
    val nativeName: NativeName,
    val official: String
)