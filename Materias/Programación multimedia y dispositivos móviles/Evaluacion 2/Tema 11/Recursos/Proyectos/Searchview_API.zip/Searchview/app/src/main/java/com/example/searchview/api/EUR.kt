package com.example.searchview.api

data class EUR(
    val name: String,
    val symbol: String
)