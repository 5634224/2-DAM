package com.example.searchview.api

data class Currencies(
    val EUR: EUR
)