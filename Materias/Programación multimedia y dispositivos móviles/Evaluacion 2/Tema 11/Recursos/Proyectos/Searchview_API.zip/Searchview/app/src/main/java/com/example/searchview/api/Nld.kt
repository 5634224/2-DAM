package com.example.searchview.api

data class Nld(
    val common: String,
    val official: String
)