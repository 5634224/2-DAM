package com.example.searchview.api

data class Bre(
    val common: String,
    val official: String
)