package com.example.searchview.api

data class Ita(
    val common: String,
    val official: String
)