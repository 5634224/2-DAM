package com.example.searchview.api

data class Swe(
    val common: String,
    val official: String
)