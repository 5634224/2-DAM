package com.example.searchview.api

data class NativeName(
    val spa: Spa
)