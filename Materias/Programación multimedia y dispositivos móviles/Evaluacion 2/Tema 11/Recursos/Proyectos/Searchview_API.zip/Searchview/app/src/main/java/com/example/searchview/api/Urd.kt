package com.example.searchview.api

data class Urd(
    val common: String,
    val official: String
)