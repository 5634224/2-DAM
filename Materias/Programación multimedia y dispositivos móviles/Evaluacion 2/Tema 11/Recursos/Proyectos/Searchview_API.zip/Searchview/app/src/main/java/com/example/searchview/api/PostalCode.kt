package com.example.searchview.api

data class PostalCode(
    val format: String,
    val regex: String
)