package com.example.searchview.api

class CountryAPI : ArrayList<CountryItem>()