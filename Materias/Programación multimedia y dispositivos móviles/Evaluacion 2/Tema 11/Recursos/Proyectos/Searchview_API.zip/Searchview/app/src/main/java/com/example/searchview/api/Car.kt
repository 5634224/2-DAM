package com.example.searchview.api

data class Car(
    val side: String,
    val signs: List<String>
)