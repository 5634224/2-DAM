package com.example.searchview.api

data class Flags(
    val alt: String,
    val png: String,
    val svg: String
)