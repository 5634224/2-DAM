package com.example.searchview.api

data class FraX(
    val common: String,
    val official: String
)