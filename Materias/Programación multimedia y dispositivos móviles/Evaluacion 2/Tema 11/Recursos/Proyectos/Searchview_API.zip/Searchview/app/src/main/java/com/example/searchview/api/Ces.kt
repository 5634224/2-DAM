package com.example.searchview.api

data class Ces(
    val common: String,
    val official: String
)