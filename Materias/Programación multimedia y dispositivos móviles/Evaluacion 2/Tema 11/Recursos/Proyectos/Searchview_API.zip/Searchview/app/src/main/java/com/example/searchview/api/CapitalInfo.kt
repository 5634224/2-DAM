package com.example.searchview.api

data class CapitalInfo(
    val latlng: List<Double>
)