package com.example.searchview.api

data class Gini(
    val `2018`: Double
)