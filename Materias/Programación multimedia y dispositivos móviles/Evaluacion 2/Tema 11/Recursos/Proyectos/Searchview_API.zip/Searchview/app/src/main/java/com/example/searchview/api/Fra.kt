package com.example.searchview.api

data class Fra(
    val f: String,
    val m: String
)