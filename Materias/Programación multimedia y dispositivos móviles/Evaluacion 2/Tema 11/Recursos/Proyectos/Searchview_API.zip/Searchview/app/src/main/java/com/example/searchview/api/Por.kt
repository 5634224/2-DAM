package com.example.searchview.api

data class Por(
    val common: String,
    val official: String
)