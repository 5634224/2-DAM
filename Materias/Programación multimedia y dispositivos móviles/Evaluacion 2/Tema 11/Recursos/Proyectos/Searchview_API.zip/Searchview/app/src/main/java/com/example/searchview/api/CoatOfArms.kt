package com.example.searchview.api

data class CoatOfArms(
    val png: String,
    val svg: String
)