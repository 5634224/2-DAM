package com.example.searchview.api

data class Tur(
    val common: String,
    val official: String
)