package com.example.searchview.api

data class Est(
    val common: String,
    val official: String
)