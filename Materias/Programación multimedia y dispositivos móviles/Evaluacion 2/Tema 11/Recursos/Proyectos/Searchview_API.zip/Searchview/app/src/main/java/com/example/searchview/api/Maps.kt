package com.example.searchview.api

data class Maps(
    val googleMaps: String,
    val openStreetMaps: String
)