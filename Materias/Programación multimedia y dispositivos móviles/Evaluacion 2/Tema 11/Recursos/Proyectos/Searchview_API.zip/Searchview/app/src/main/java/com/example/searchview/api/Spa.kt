package com.example.searchview.api

data class Spa(
    val common: String,
    val official: String
)