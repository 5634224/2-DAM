package com.example.searchview.api

data class Languages(
    val cat: String,
    val eus: String,
    val glc: String,
    val spa: String
)