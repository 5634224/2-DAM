package com.example.searchview.api

data class Eng(
    val f: String,
    val m: String
)