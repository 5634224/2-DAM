package com.example.searchview.api

data class Hun(
    val common: String,
    val official: String
)