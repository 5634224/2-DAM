package com.example.searchview.api.rv

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.searchview.R
import com.example.searchview.api.CountryItem

class CountryItemAPIAdapter(private val countries: List<CountryItem>) : RecyclerView.Adapter<CountryItemAPIAdapter.CountryViewHolder>()
{

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CountryViewHolder
    {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_country_api, parent, false)
        return CountryViewHolder(view)
    }

    override fun onBindViewHolder(holder: CountryViewHolder, position: Int)
    {
        val country = countries[position]
        holder.bind(country)
    }

    override fun getItemCount() = countries.size

    class CountryViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView)
    {
        private val tvCountryName: TextView = itemView.findViewById(R.id.tvCountryName)
        private val tvCapital: TextView = itemView.findViewById(R.id.tvCapital)

        fun bind(country: CountryItem)
        {
            tvCountryName.text = country.name.common // Asumiendo que 'name' tiene un campo 'common'
            tvCapital.text = "Capital: ${country.capital.joinToString()}"
        }
    }
}