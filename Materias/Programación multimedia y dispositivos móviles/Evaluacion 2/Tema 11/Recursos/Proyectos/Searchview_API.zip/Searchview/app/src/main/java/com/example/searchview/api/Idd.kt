package com.example.searchview.api

data class Idd(
    val root: String,
    val suffixes: List<String>
)