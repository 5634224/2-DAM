package com.example.searchview.api

data class Rus(
    val common: String,
    val official: String
)