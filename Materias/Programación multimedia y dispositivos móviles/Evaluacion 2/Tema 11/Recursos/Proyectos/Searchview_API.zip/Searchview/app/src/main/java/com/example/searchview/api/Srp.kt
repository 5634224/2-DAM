package com.example.searchview.api

data class Srp(
    val common: String,
    val official: String
)