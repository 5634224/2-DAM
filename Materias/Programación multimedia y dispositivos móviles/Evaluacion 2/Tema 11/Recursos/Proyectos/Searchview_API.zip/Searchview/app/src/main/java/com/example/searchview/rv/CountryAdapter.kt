package com.example.searchview.rv

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.searchview.R

class CountryAdapter(private val countries: List<Country>) : RecyclerView.Adapter<CountryAdapter.ViewHolder>()
{

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CountryAdapter.ViewHolder
    {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_country, parent, false)

        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(countries[position])
    }

    override fun getItemCount(): Int = countries.size

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView)
    {
        private val countryName: TextView = itemView.findViewById(R.id.countryName)
        private val countryCapital: TextView = itemView.findViewById(R.id.countryCapital)
        private val countryFlag: ImageView = itemView.findViewById(R.id.imageView)

        fun bind(country: Country)
        {
            countryName.text = country.name
            countryCapital.text = country.capital

            if (!country.bandera.isNullOrEmpty())
            {
                //Asignar imagen
                Glide.with(countryFlag.context)
                    .load(country.bandera)
                    .override(120,80)
                    .into(countryFlag)
            }
            else
            {
            }


        }
    }
}



