package com.example.searchview.api

data class Cym(
    val common: String,
    val official: String
)