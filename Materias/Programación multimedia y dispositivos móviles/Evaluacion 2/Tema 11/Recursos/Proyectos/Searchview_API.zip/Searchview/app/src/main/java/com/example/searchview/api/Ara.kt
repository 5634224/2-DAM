package com.example.searchview.api

data class Ara(
    val common: String,
    val official: String
)