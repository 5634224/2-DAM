package com.example.searchview.api

data class Zho(
    val common: String,
    val official: String
)