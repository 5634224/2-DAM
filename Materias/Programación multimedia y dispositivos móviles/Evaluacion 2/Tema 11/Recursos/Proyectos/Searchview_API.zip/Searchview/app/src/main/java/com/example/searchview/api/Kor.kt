package com.example.searchview.api

data class Kor(
    val common: String,
    val official: String
)