package com.example.searchview.api

data class Demonyms(
    val eng: Eng,
    val fra: Fra
)