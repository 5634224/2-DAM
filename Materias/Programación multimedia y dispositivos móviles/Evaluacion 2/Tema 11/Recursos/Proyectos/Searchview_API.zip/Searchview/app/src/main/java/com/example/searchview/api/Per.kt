package com.example.searchview.api

data class Per(
    val common: String,
    val official: String
)