package com.example.searchview.api

data class Deu(
    val common: String,
    val official: String
)