package com.example.searchview.api

data class Hrv(
    val common: String,
    val official: String
)