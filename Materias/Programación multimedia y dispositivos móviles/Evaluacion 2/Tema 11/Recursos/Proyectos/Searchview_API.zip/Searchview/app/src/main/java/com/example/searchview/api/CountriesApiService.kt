package com.example.searchview.api

import com.example.searchview.rv.Country
import retrofit2.Call
import retrofit2.Response
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query


interface CountriesApiService {
    @GET("{subRegion}")
    suspend fun getCountryInfo(
        @Path("subRegion") subRegion: String
        ): Response<List<CountryItem>>
}