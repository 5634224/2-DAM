package com.example.persistencia

import android.content.Context
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.View.OnClickListener
import com.example.persistencia.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity(), OnClickListener
{
    private lateinit var binding: ActivityMainBinding
    private val sharedPref by lazy { getSharedPreferences(getString(R.string.preference_file_key), Context.MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?)
    {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        val view = binding.root

        setContentView(view)

        binding.btnGuardar.setOnClickListener(this)
        binding.btnLeer.setOnClickListener(this)

    }

    override fun onClick(p0: View?)
    {
        if (p0?.id == binding.btnGuardar.id)
        {
            //Guardamos la clave en el fichero
            sharedPref.edit().putString(binding.textInputKey.text.toString(), binding.textInputValue.text.toString()).apply()
        }
        else
        {
            val value = sharedPref.getString(binding.textInputKey.text.toString(), "No se ha encontrado el valor")
            binding.tvValue.text = value
        }
    }
}