package com.example.searchview

import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.ProgressBar
import androidx.appcompat.app.AppCompatActivity
import android.widget.SearchView
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.searchview.rv.Country
import com.example.searchview.rv.CountryAdapter
import com.google.firebase.Firebase
import com.google.firebase.firestore.firestore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import com.google.firebase.storage.FirebaseStorage

class MainActivity: AppCompatActivity() {

    private lateinit var searchView: SearchView
    private lateinit var recyclerView: RecyclerView
    private lateinit var progressBar: ProgressBar
    private lateinit var allCountries: MutableList<Country>
    private lateinit var filteredCountries: MutableList<Country>

    // Access a Cloud Firestore instance from your Activity
    private val db = Firebase.firestore
    private val countries = db.collection("paises")

    //Acceso a la nube(storage) de Firebase
    val storage = FirebaseStorage.getInstance()
    val storageRef = storage.reference

    /*= listOf(
        Country("Argentina", "Buenos Aires", ""),
        Country("Brasil", "Brasilia", ""),
        Country("Canadá", "Ottawa", ""),
        Country("Alemania", "Berlín", ""),
        Country("India", "Nueva Delhi", ""),
        Country("Japón", "Tokio", ""),
        Country("Estados Unidos", "Washington D.C.", ""),
        // Add more countries as needed
    )*/

    override fun onCreate(savedInstanceState: Bundle?)
    {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        searchView = findViewById(R.id.searchView)
        recyclerView = findViewById(R.id.recyclerView)
        progressBar = findViewById(R.id.progressBar)

        GlobalScope.launch(Dispatchers.Main)
        {
            recyclerView.layoutManager = LinearLayoutManager(applicationContext)
            allCountries = mutableListOf()

            searchView.visibility = View.GONE
            // Mostrar la ProgressBar
            progressBar.visibility = View.VISIBLE

            //await hace que no se ejecuten las líneas a continuación, hasta finalizar esta tarea
            cargarPaises()

            // Ocultar la ProgressBar cuando la operación se completa
            progressBar.visibility = View.GONE
            searchView.visibility = View.VISIBLE

            filteredCountries = allCountries.toMutableList()
            val adapter = CountryAdapter(filteredCountries)
            recyclerView.adapter = adapter
        }

        searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {

                override fun onQueryTextSubmit(query: String?): Boolean
                {
                    return false
                }

                override fun onQueryTextChange(newText: String?): Boolean
                {
                    filterCountries(newText)
                    return true
                }
        })
    }

    private fun filterCountries(query: String?)
    {
        filteredCountries.clear()

        if (query.isNullOrEmpty()) {
            filteredCountries.addAll(allCountries)
        } else {
            val lowercaseQuery = query.lowercase()
            filteredCountries.addAll(
                allCountries.filter { country ->
                    country.name.lowercase().contains(lowercaseQuery)
                }
            )
        }

        recyclerView.adapter?.notifyDataSetChanged()
    }

    private suspend fun cargarPaises()
    {
        withContext(Dispatchers.IO)
        {
            //Cargar países
            //CORRUTINAS - GET ES ASÍNCRONO
            val docRef = countries.document("Argentina")
            docRef.get()
                .addOnSuccessListener { document ->
                    if (document != null) {
                        var pais: Country =
                            Country(document.get("nombre").toString(), document.get("capital").toString(), document.get("bandera").toString())
                        allCountries.add(pais)

                    } else {
                        Log.d("Firebase", "No such document")
                    }
                }
                .addOnFailureListener { exception ->
                    Log.d("Firebase", "get failed with ", exception)


                }.await()
        }
    }

}