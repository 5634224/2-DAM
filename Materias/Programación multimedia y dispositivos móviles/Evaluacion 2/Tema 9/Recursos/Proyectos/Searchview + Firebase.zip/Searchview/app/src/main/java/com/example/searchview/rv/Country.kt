package com.example.searchview.rv

data class Country(var name: String, val capital: String, val bandera: String)